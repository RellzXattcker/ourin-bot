import axios from 'axios';

// Konfigurasi dasar plugin
const pluginConfig = {
    name: 'tictactoe2p',
    alias: ['ttt2p', 'tictactoeberdua'],
    category: 'games',
    description: 'Main Tic Tac Toe berdua (2 Player) langsung di chat WhatsApp',
    usage: '.ttt2p',
    example: '.ttt2p',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 2,
    isEnabled: true
};

// Fungsi untuk me-render HTML Tic Tac Toe 2 Player (UI & Logic JS)
function renderHtmlTicTacToe2P() {
    return `
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; user-select: none; font-family: 'Segoe UI', Roboto, Helvetica, sans-serif; }
body { margin: 0; background: transparent; color: #f2e9e4; }
.ttt-wrap { width: 100%; max-width: 400px; margin: auto; padding: 12px; }
.ttt-card {
  background: linear-gradient(180deg, rgba(40,45,60,0.85) 0%, rgba(15,18,25,0.97) 55%);
  border-radius: 18px; overflow: hidden; box-shadow: 0 10px 34px rgba(0,0,0,0.6);
  padding: 18px; border: 1px solid rgba(255,255,255,0.05);
}
.header { text-align: center; margin-bottom: 15px; }
.title { font-size: 16px; font-weight: 700; color: #fff; letter-spacing: 1px; }
.subtitle { font-size: 11px; color: #a0aec0; margin-top: 4px; font-style: italic; }
.status-bar { display: flex; justify-content: space-between; font-size: 12px; color: #cbd5e0; margin-bottom: 15px; font-weight: 600; padding: 0 4px; }
.status-bar .turn { color: #ff6b5e; transition: color 0.3s; }
.board-container { width: 100%; aspect-ratio: 1; border-radius: 12px; overflow: hidden; background: #2d3748; position: relative; padding: 8px; }
.board { display: grid; grid-template-columns: repeat(3, 1fr); grid-template-rows: repeat(3, 1fr); gap: 8px; width: 100%; height: 100%; }
.cell { background: #1a202c; border-radius: 8px; display: flex; justify-content: center; align-items: center; font-size: 4rem; font-weight: bold; cursor: pointer; transition: background 0.2s; box-shadow: inset 0 2px 4px rgba(0,0,0,0.3); }
.cell:active { background: #171923; }
.cell.x { color: #ff6b5e; }
.cell.o { color: #4fd1c5; }
.overlay { position: absolute; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.75); display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 10; display: none; backdrop-filter: blur(2px); }
.overlay-text { font-size: 24px; font-weight: bold; color: #fff; margin-bottom: 15px; text-transform: uppercase; letter-spacing: 2px; }
.btn { background: rgba(255,255,255,0.1); border: 1px solid rgba(255,255,255,0.2); color: #fff; padding: 10px 20px; border-radius: 20px; font-size: 13px; font-weight: 600; cursor: pointer; transition: all 0.2s; }
.btn:active { background: rgba(255,255,255,0.2); transform: scale(0.95); }
</style>
<div class="ttt-wrap">
  <div class="ttt-card">
    <div class="header">
      <div class="title">TIC TAC TOE</div>
      <div class="subtitle">2 Player Mode (Berdua)</div>
    </div>
    <div class="status-bar">
      <span>Player 1: <strong style="color:#ff6b5e;">X</strong></span>
      <span id="turnIndicator" class="turn">Giliran Player X</span>
      <span>Player 2: <strong style="color:#4fd1c5;">O</strong></span>
    </div>
    <div class="board-container">
      <div id="board" class="board">
        <div class="cell" data-index="0"></div><div class="cell" data-index="1"></div><div class="cell" data-index="2"></div>
        <div class="cell" data-index="3"></div><div class="cell" data-index="4"></div><div class="cell" data-index="5"></div>
        <div class="cell" data-index="6"></div><div class="cell" data-index="7"></div><div class="cell" data-index="8"></div>
      </div>
      <div id="gameOverlay" class="overlay">
        <div id="overlayText" class="overlay-text">Player X Wins!</div>
        <button class="btn" onclick="initGame()">Main Lagi</button>
      </div>
    </div>
  </div>
</div>
<script>
(function(){
    const cells = document.querySelectorAll('.cell');
    const turnInd = document.getElementById('turnIndicator');
    const overlay = document.getElementById('gameOverlay');
    const overlayText = document.getElementById('overlayText');

    let board = ['', '', '', '', '', '', '', '', ''];
    let currentPlayer = 'X'; // X mulai duluan
    let gameOver = false;

    const winCombos = [
        [0, 1, 2], [3, 4, 5], [6, 7, 8], // Rows
        [0, 3, 6], [1, 4, 7], [2, 5, 8], // Cols
        [0, 4, 8], [2, 4, 6]             // Diagonals
    ];

    cells.forEach(cell => {
        cell.addEventListener('click', () => {
            if (gameOver) return;
            const idx = cell.getAttribute('data-index');
            
            if (board[idx] === '') {
                board[idx] = currentPlayer;
                cell.textContent = currentPlayer;
                cell.classList.add(currentPlayer.toLowerCase());

                if (checkWin(board, currentPlayer)) {
                    endGame('Player ' + currentPlayer + ' Menang!');
                } else if (checkTie()) {
                    endGame("Seri (Draw)!");
                } else {
                    // Tukar giliran
                    currentPlayer = currentPlayer === 'X' ? 'O' : 'X';
                    turnInd.textContent = 'Giliran Player ' + currentPlayer;
                    turnInd.style.color = currentPlayer === 'X' ? '#ff6b5e' : '#4fd1c5';
                }
            }
        });
    });

    function checkWin(currentBoard, playerSign) {
        return winCombos.some(combo => {
            return combo.every(index => currentBoard[index] === playerSign);
        });
    }

    function checkTie() {
        return board.every(cell => cell !== '');
    }

    function endGame(msg) {
        gameOver = true;
        turnInd.textContent = "Permainan Selesai";
        turnInd.style.color = '#cbd5e0';
        setTimeout(() => {
            overlayText.textContent = msg;
            overlay.style.display = 'flex';
        }, 300);
    }

    window.initGame = function() {
        board = ['', '', '', '', '', '', '', '', ''];
        currentPlayer = 'X';
        gameOver = false;
        overlay.style.display = 'none';
        turnInd.textContent = "Giliran Player X";
        turnInd.style.color = '#ff6b5e';
        cells.forEach(cell => {
            cell.textContent = '';
            cell.classList.remove('x', 'o');
        });
    }
})();
</script>
`;
}

// Handler utama bot
async function handler(m, { sock, conn }) {
    const client = sock || conn;

    if (typeof m.react === 'function') await m.react('🎮');

    try {
        const htmlPayload = renderHtmlTicTacToe2P();

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "kurumi-tictactoe-2p",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `Game Tic Tac Toe Berdua Dimulai!` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "kurumi-tictactoe-2p",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

    } catch (error) {
        console.error('TicTacToe 2P Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler };