const pluginConfig = {
    name: 'angrybirds',
    alias: ['angry', 'birds', 'angrybird'],
    category: 'games',
    description: 'Main game Angry Birds (tembak babi hijau) dengan rasio 16:9 langsung di chat',
    usage: '.angrybirds',
    example: '.angrybirds',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 5,
    isEnabled: true
};

function renderHtmlAngryBirds() {
    return `
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<style>
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; user-select: none; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
body { margin: 0; background: transparent; color: #fff; overflow: hidden; touch-action: none; }
.game-wrap { width: 100%; max-width: 420px; margin: auto; padding: 10px; }
.game-card {
  background: #1e1e2e;
  border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.8);
  padding: 14px; border: 2px solid #313244;
}
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.title { font-size: 16px; font-weight: 900; color: #f38ba8; letter-spacing: 1px; text-transform: uppercase; }
.info-box { background: #313244; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: bold; color: #a6e3a1; }
.canvas-container { width: 100%; aspect-ratio: 16/9; border-radius: 8px; background: #89b4fa; position: relative; overflow: hidden; border: 2px solid #45475a; }
canvas { display: block; width: 100%; height: 100%; }
.overlay { position: absolute; inset: 0; background: rgba(17, 17, 27, 0.88); display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 10; padding: 20px; text-align: center; }
.overlay-title { font-size: 22px; font-weight: 900; color: #f38ba8; margin-bottom: 8px; text-shadow: 0 2px 4px rgba(0,0,0,0.5); }
.overlay-desc { font-size: 12px; color: #bac2de; margin-bottom: 16px; line-height: 1.4; }
.btn { background: #f38ba8; border: none; color: #11111b; padding: 10px 22px; border-radius: 12px; font-size: 14px; font-weight: bold; cursor: pointer; transition: 0.2s; }
.btn:active { transform: scale(0.95); background: #eba0ac; }
.footer-tip { text-align: center; font-size: 10px; color: #6c7086; margin-top: 10px; }
</style>
<div class="game-wrap">
  <div class="game-card">
    <div class="header">
      <div class="title">Jaka Angry Birds</div>
      <div class="info-box">Babi: <span id="pigVal">3</span> | Sisa: <span id="birdVal">3</span></div>
    </div>
    <div class="canvas-container">
      <canvas id="gameCanvas" width="320" height="180"></canvas>
      <div id="messageOverlay" class="overlay">
        <div class="overlay-title" id="overlayTitle">ANGRY BIRDS 16:9</div>
        <div class="overlay-desc" id="overlayDesc">Tarik burung merah lalu lepaskan untuk menghancurkan babi hijau!</div>
        <button class="btn" id="overlayBtn" onclick="startGame()">Mulai Main</button>
      </div>
    </div>
    <div class="footer-tip">Seret (Drag) burung dari ketapel di sebelah kiri ke arah belakang.</div>
  </div>
</div>
<script>
(function(){
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    
    let gameState = 'start'; 
    let birdsLeft = 3;
    let pigsLeft = 3;

    const sling = { x: 60, y: 130 };
    let bird = { x: 60, y: 130, vx: 0, vy: 0, r: 8, flying: false, held: false };
    let pigs = [];
    let obstacles = [];

    function resetLevel() {
        birdsLeft = 3;
        pigsLeft = 3;
        spawnEntities();
        resetBird();
        updateUI();
    }

    function spawnEntities() {
        pigs = [
            { x: 240, y: 135, r: 9, alive: true },
            { x: 270, y: 110, r: 9, alive: true },
            { x: 255, y: 80, r: 9, alive: true }
        ];
        obstacles = [
            { x: 230, y: 110, w: 12, h: 35 },
            { x: 265, y: 95, w: 12, h: 50 }
        ];
    }

    function resetBird() {
        bird.x = sling.x;
        bird.y = sling.y;
        bird.vx = 0;
        bird.vy = 0;
        bird.flying = false;
        bird.held = false;
    }

    function updateUI() {
        document.getElementById('birdVal').textContent = birdsLeft;
        document.getElementById('pigVal').textContent = pigsLeft;
    }

    window.startGame = function() {
        document.getElementById('messageOverlay').style.display = 'none';
        resetLevel();
        gameState = 'playing';
    }

    function checkGameOver() {
        if (pigsLeft <= 0) {
            gameState = 'win';
            document.getElementById('overlayTitle').textContent = "MENANG!";
            document.getElementById('overlayTitle').style.color = "#a6e3a1";
            document.getElementById('overlayDesc').textContent = "Semua babi hijau berhasil dibasmi!";
            document.getElementById('overlayBtn').textContent = "Main Lagi";
            document.getElementById('messageOverlay').style.display = 'flex';
        } else if (birdsLeft <= 0 && !bird.flying) {
            gameState = 'gameover';
            document.getElementById('overlayTitle').textContent = "KALAH!";
            document.getElementById('overlayTitle').style.color = "#f38ba8";
            document.getElementById('overlayDesc').textContent = "Burung habis, babi masih selamat.";
            document.getElementById('overlayBtn').textContent = "Coba Lagi";
            document.getElementById('messageOverlay').style.display = 'flex';
        }
    }

    function update() {
        if (gameState !== 'playing') return;

        if (bird.flying) {
            bird.vy += 0.25; // Gravitasi
            bird.x += bird.vx;
            bird.y += bird.vy;

            // Tabrakan dengan tanah
            if (bird.y >= 145) {
                bird.y = 145;
                bird.vx *= 0.6;
                if (Math.abs(bird.vx) < 0.5) {
                    bird.flying = false;
                    checkGameOver();
                    if (birdsLeft > 0 && pigsLeft > 0) resetBird();
                }
            }

            // Tabrakan dengan rintangan balok
            obstacles.forEach(obs => {
                if (bird.x + bird.r > obs.x && bird.x - bird.r < obs.x + obs.w &&
                    bird.y + bird.r > obs.y && bird.y - bird.r < obs.y + obs.h) {
                    bird.vx *= -0.5;
                    obs.hit = (obs.hit || 0) + 1;
                }
            });

            // Tabrakan dengan babi hijau
            pigs.forEach(p => {
                if (p.alive) {
                    let dx = bird.x - p.x;
                    let dy = bird.y - p.y;
                    let dist = Math.sqrt(dx * dx + dy * dy);
                    if (dist < bird.r + p.r) {
                        p.alive = false;
                        pigsLeft--;
                        updateUI();
                        bird.vx *= 0.5;
                    }
                }
            });
        }
    }

    function draw() {
        // Background Langit 16:9 (320x180)
        ctx.fillStyle = '#89b4fa';
        ctx.fillRect(0, 0, 320, 180);

        // Tanah
        ctx.fillStyle = '#a6e3a1';
        ctx.fillRect(0, 145, 320, 35);
        ctx.fillStyle = '#94e2d5';
        ctx.fillRect(0, 145, 320, 5);

        // Ketapel
        ctx.strokeStyle = '#585b70';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(sling.x, sling.y + 15);
        ctx.lineTo(sling.x, sling.y);
        ctx.stroke();

        // Karet ketapel jika sedang ditarik
        if (bird.held) {
            ctx.strokeStyle = '#45475a';
            ctx.lineWidth = 2;
            ctx.beginPath();
            ctx.moveTo(sling.x - 6, sling.y - 2);
            ctx.lineTo(bird.x, bird.y);
            ctx.lineTo(sling.x + 6, sling.y - 2);
            ctx.stroke();
        }

        // Gambar Balok Rintangan
        obstacles.forEach(obs => {
            ctx.fillStyle = '#fab387';
            ctx.fillRect(obs.x, obs.y, obs.w, obs.h);
            ctx.strokeStyle = '#ef6461';
            ctx.strokeRect(obs.x, obs.y, obs.w, obs.h);
        });

        // Gambar Babi Hijau
        pigs.forEach(p => {
            if (p.alive) {
                ctx.fillStyle = '#a6e3a1';
                ctx.beginPath();
                ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
                ctx.fill();
                // Mata babi
                ctx.fillStyle = '#fff';
                ctx.beginPath(); ctx.arc(p.x - 3, p.y - 2, 2.5, 0, Math.PI*2); ctx.fill();
                ctx.beginPath(); ctx.arc(p.x + 3, p.y - 2, 2.5, 0, Math.PI*2); ctx.fill();
                ctx.fillStyle = '#000';
                ctx.beginPath(); ctx.arc(p.x - 3, p.y - 2, 1, 0, Math.PI*2); ctx.fill();
                ctx.beginPath(); ctx.arc(p.x + 3, p.y - 2, 1, 0, Math.PI*2); ctx.fill();
            }
        });

        // Gambar Burung Merah
        ctx.fillStyle = '#f38ba8';
        ctx.beginPath();
        ctx.arc(bird.x, bird.y, bird.r, 0, Math.PI * 2);
        ctx.fill();
        // Paruh burung
        ctx.fillStyle = '#fab387';
        ctx.beginPath();
        ctx.moveTo(bird.x + bird.r - 2, bird.y);
        ctx.lineTo(bird.x + bird.r + 5, bird.y + 3);
        ctx.lineTo(bird.x + bird.r - 2, bird.y + 5);
        ctx.fill();
    }

    function loop() {
        update();
        draw();
        requestAnimationFrame(loop);
    }

    // Touch & Mouse Drag Handling untuk ketapel
    const getPos = (e) => {
        const rect = canvas.getBoundingClientRect();
        const clientX = e.touches ? e.touches[0].clientX : e.clientX;
        const clientY = e.touches ? e.touches[0].clientY : e.clientY;
        return {
            x: (clientX - rect.left) * (320 / rect.width),
            y: (clientY - rect.top) * (180 / rect.height)
        };
    };

    canvas.addEventListener('pointerdown', (e) => {
        if (gameState !== 'playing' || bird.flying) return;
        let pos = getPos(e);
        let dist = Math.sqrt(Math.pow(pos.x - bird.x, 2) + Math.pow(pos.y - bird.y, 2));
        if (dist < 25) {
            bird.held = true;
        }
    });

    canvas.addEventListener('pointermove', (e) => {
        if (!bird.held) return;
        let pos = getPos(e);
        // Batasi jarak tarik ketapel
        let dx = pos.x - sling.x;
        let dy = pos.y - sling.y;
        let dist = Math.sqrt(dx*dx + dy*dy);
        if (dist > 40) {
            dx = (dx / dist) * 40;
            dy = (dy / dist) * 40;
        }
        // Jangan biarkan ditarik ke depan (harus ke belakang/kiri ketapel)
        if (dx > 0) dx = 0;

        bird.x = sling.x + dx;
        bird.y = sling.y + dy;
    });

    canvas.addEventListener('pointerup', (e) => {
        if (!bird.held) return;
        bird.held = false;
        bird.flying = true;
        
        // Hitung kecepatan lemparan berdasarkan jarak tarik
        let dx = sling.x - bird.x;
        let dy = sling.y - bird.y;
        bird.vx = dx * 0.22;
        bird.vy = dy * 0.22;

        birdsLeft--;
        updateUI();
    });

    resetLevel();
    draw();
    loop();
})();
</script>
`;
}

async function handler(m, { sock, conn }) {
    const client = sock || conn;

    if (typeof m.react === 'function') await m.react('🐦');

    try {
        const htmlPayload = renderHtmlAngryBirds();

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "jaka-angrybirds-game",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `Game Jaka Angry Birds Dimulai!` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "jaka-angrybirds-game",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

    } catch (error) {
        console.error('Angry Birds Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler };