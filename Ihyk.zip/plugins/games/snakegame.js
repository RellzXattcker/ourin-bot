// Konfigurasi dasar plugin
const pluginConfig = {
    name: 'snakegame',
    alias: ['snake', 'ular', 'nokiasnake'],
    category: 'games',
    description: 'Main game ular legendaris ala Nokia langsung di chat WhatsApp',
    usage: '.snake',
    example: '.snake',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 5,
    isEnabled: true
};

function renderHtmlSnake() {
    return `
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; user-select: none; font-family: 'Courier New', Courier, monospace; }
body { margin: 0; background: transparent; color: #122012; overflow: hidden; }
.game-wrap { width: 100%; max-width: 400px; margin: auto; padding: 10px; }
.game-card {
  background: #9ead86;
  border-radius: 12px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.7);
  padding: 14px; border: 4px solid #33412b;
}
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; font-weight: bold; }
.title { font-size: 16px; color: #1b281b; letter-spacing: 1px; text-transform: uppercase; }
.score-box { background: #8b9b75; padding: 4px 10px; border-radius: 4px; font-size: 13px; color: #111; border: 1px solid #5a6b47; }
.board-container { width: 100%; aspect-ratio: 1; border-radius: 4px; background: #94a37e; padding: 2px; border: 3px solid #5a6b47; position: relative; }
.board { display: grid; grid-template-columns: repeat(16, 1fr); grid-template-rows: repeat(16, 1fr); width: 100%; height: 100%; background: #9ead86; }
.cell { width: 100%; height: 100%; }
.cell.snake { background: #1b281b; border-radius: 1px; }
.cell.food { background: #1b281b; border-radius: 50%; transform: scale(0.8); }
.overlay { position: absolute; inset: 0; background: rgba(158, 173, 134, 0.92); display: none; flex-direction: column; justify-content: center; align-items: center; z-index: 10; border-radius: 4px; }
.overlay-title { font-size: 20px; font-weight: bold; color: #1b281b; margin-bottom: 5px; }
.overlay-score { font-size: 14px; color: #33412b; margin-bottom: 15px; }
.btn { background: #1b281b; border: none; color: #9ead86; padding: 8px 18px; border-radius: 4px; font-size: 13px; font-weight: bold; cursor: pointer; }
.dpad { display: grid; grid-template-columns: repeat(3, 1fr); gap: 6px; width: 160px; margin: 12px auto 0 auto; }
.dpad-btn { background: #8b9b75; border: 2px solid #5a6b47; color: #1b281b; font-size: 16px; height: 42px; border-radius: 6px; display: flex; justify-content: center; align-items: center; cursor: pointer; font-weight: bold; }
.dpad-btn:active { background: #5a6b47; color: #9ead86; }
.dpad-empty { border: none; background: transparent; }
.info-text { text-align: center; font-size: 9px; color: #33412b; margin-top: 8px; font-weight: bold; }
</style>
<div class="game-wrap">
  <div class="game-card">
    <div class="header">
      <div class="title">Nokia Snake</div>
      <div class="score-box">Score: <span id="scoreVal">0</span></div>
    </div>
    <div class="board-container">
      <div id="board" class="board"></div>
      <div id="gameOverOverlay" class="overlay">
        <div class="overlay-title">GAME OVER</div>
        <div class="overlay-score">Score: <span id="finalScore">0</span></div>
        <button class="btn" onclick="initGame()">TRY AGAIN</button>
      </div>
    </div>
    <div class="dpad">
      <div class="dpad-empty"></div>
      <button class="dpad-btn" id="btnUp">▲</button>
      <div class="dpad-empty"></div>
      <button class="dpad-btn" id="btnLeft">◀</button>
      <div class="dpad-empty"></div>
      <button class="dpad-btn" id="btnRight">▶</button>
      <div class="dpad-empty"></div>
      <button class="dpad-btn" id="btnDown">▼</button>
      <div class="dpad-empty"></div>
    </div>
    <div class="info-text">Gunakan tombol arah di bawah untuk mengontrol ular.</div>
  </div>
</div>
<script>
(function(){
    const SIZE = 16;
    let board = [];
    let snake = [];
    let food = {x: 0, y: 0};
    let dx = 1;
    let dy = 0;
    let score = 0;
    let gameInterval = null;
    let gameOver = false;

    const boardEl = document.getElementById('board');
    const scoreEl = document.getElementById('scoreVal');
    const overlay = document.getElementById('gameOverOverlay');
    const finalScoreEl = document.getElementById('finalScore');

    function createBoard() {
        boardEl.innerHTML = '';
        for(let r=0; r<SIZE; r++){
            for(let c=0; c<SIZE; c++){
                let cell = document.createElement('div');
                cell.className = 'cell';
                cell.dataset.r = r;
                cell.dataset.c = c;
                boardEl.appendChild(cell);
            }
        }
    }

    function render() {
        const cells = boardEl.children;
        for(let i=0; i<cells.length; i++){
            cells[i].className = 'cell';
        }

        // Render Snake
        snake.forEach(part => {
            let idx = part.y * SIZE + part.x;
            if(cells[idx]) cells[idx].classList.add('snake');
        });

        // Render Food
        let foodIdx = food.y * SIZE + food.x;
        if(cells[foodIdx]) cells[foodIdx].classList.add('food');
    }

    function spawnFood() {
        let valid = false;
        while(!valid) {
            food = {
                x: Math.floor(Math.random() * SIZE),
                y: Math.floor(Math.random() * SIZE)
            };
            valid = !snake.some(part => part.x === food.x && part.y === food.y);
        }
    }

    function update() {
        if(gameOver) return;

        let head = {x: snake[0].x + dx, y: snake[0].y + dy};

        // Cek tabrakan dinding atau badan sendiri
        if(head.x < 0 || head.x >= SIZE || head.y < 0 || head.y >= SIZE || snake.some(p => p.x === head.x && p.y === head.y)) {
            endGame();
            return;
        }

        snake.unshift(head);

        // Cek makan makanan
        if(head.x === food.x && head.y === food.y) {
            score += 10;
            scoreEl.textContent = score;
            spawnFood();
        } else {
            snake.pop();
        }

        render();
    }

    function changeDirection(newDx, newDy) {
        // Mencegah ular berbalik arah 180 derajat secara langsung
        if(newDx !== -dx || newDy !== -dy) {
            dx = newDx;
            dy = newDy;
        }
    }

    function endGame() {
        gameOver = true;
        clearInterval(gameInterval);
        finalScoreEl.textContent = score;
        overlay.style.display = 'flex';
    }

    window.initGame = function() {
        clearInterval(gameInterval);
        snake = [{x: 8, y: 8}, {x: 7, y: 8}, {x: 6, y: 8}];
        dx = 1;
        dy = 0;
        score = 0;
        scoreEl.textContent = score;
        gameOver = false;
        overlay.style.display = 'none';
        createBoard();
        spawnFood();
        render();
        gameInterval = setInterval(update, 200);
    }

    // Event Controls D-Pad
    document.getElementById('btnUp').onclick = () => changeDirection(0, -1);
    document.getElementById('btnDown').onclick = () => changeDirection(0, 1);
    document.getElementById('btnLeft').onclick = () => changeDirection(-1, 0);
    document.getElementById('btnRight').onclick = () => changeDirection(1, 0);

    initGame();
})();
</script>
`;
}

async function handler(m, { sock, conn }) {
    const client = sock || conn;

    if (typeof m.react === 'function') await m.react('🐍');

    try {
        const htmlPayload = renderHtmlSnake();

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "kurumi-snake-game",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `Game Nokia Snake Dimulai!` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "kurumi-snake-game",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

    } catch (error) {
        console.error('Snake Game Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler };