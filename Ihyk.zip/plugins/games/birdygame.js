const pluginConfig = {
    name: 'birdygame',
    alias: ['birdy', 'flappy', 'burung'],
    category: 'games',
    description: 'Main game birdy burung ala Flappy Bird langsung di chat',
    usage: '.birdy',
    example: '.birdy',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 5,
    isEnabled: true
};

function renderHtmlBirdy() {
    return `
<meta name="viewport" content="width=device-width,initial-scale=1.0">
<style>
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; user-select: none; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
body { margin: 0; background: transparent; color: #fff; overflow: hidden; }
.game-wrap { width: 100%; max-width: 400px; margin: auto; padding: 10px; }
.game-card {
  background: #181825;
  border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.8);
  padding: 14px; border: 2px solid #313244;
}
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.title { font-size: 16px; font-weight: 800; color: #f9e2af; letter-spacing: 1px; text-transform: uppercase; }
.info-box { background: #313244; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: bold; color: #fab387; }
.canvas-container { width: 100%; aspect-ratio: 4/3; border-radius: 8px; background: #70c5ce; position: relative; overflow: hidden; border: 2px solid #45475a; }
canvas { display: block; width: 100%; height: 100%; background: #70c5ce; }
.controls { display: flex; justify-content: center; margin-top: 12px; }
.ctrl-btn { width: 100%; background: #f9e2af; border: none; color: #11111b; font-size: 16px; padding: 14px; border-radius: 10px; cursor: pointer; font-weight: bold; text-align: center; }
.ctrl-btn:active { background: #fab387; transform: scale(0.98); }
.overlay { position: absolute; inset: 0; background: rgba(17, 17, 27, 0.9); display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 10; padding: 20px; text-align: center; }
.overlay-title { font-size: 22px; font-weight: 800; color: #f9e2af; margin-bottom: 6px; }
.overlay-desc { font-size: 13px; color: #bac2de; margin-bottom: 16px; line-height: 1.4; }
.btn { background: #a6e3a1; border: none; color: #11111b; padding: 10px 22px; border-radius: 12px; font-size: 14px; font-weight: bold; cursor: pointer; }
.btn:active { transform: scale(0.95); }
.footer-tip { text-align: center; font-size: 10px; color: #6c7086; margin-top: 10px; }
</style>
<div class="game-wrap">
  <div class="game-card">
    <div class="header">
      <div class="title">Jaka Birdy</div>
      <div class="info-box">Skor: <span id="scoreVal">0</span></div>
    </div>
    <div class="canvas-container">
      <canvas id="gameCanvas" width="320" height="240"></canvas>
      <div id="messageOverlay" class="overlay">
        <div class="overlay-title" id="overlayTitle">BIRDY GAME</div>
        <div class="overlay-desc" id="overlayDesc">Tap tombol di bawah untuk menerbangkan burung melewati pipa!</div>
        <button class="btn" id="overlayBtn" onclick="startGame()">Mulai Main</button>
      </div>
    </div>
    <div class="controls">
      <button class="ctrl-btn" id="flapBtn">TERBANG / TAP</button>
    </div>
    <div class="footer-tip">Hindari pipa hijau dan jangan sampai jatuh ke tanah!</div>
  </div>
</div>
<script>
(function(){
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    
    let score = 0;
    let gameState = 'start'; // start, playing, gameover

    let bird = {
        x: 50, y: 120, r: 10,
        gravity: 0.35, lift: -6.5, velocity: 0
    };

    let pipes = [];
    let pipeWidth = 40;
    let pipeGap = 75;
    let frameCount = 0;

    function resetGame() {
        bird.y = 120;
        bird.velocity = 0;
        pipes = [];
        score = 0;
        frameCount = 0;
        document.getElementById('scoreVal').textContent = score;
    }

    window.startGame = function() {
        document.getElementById('messageOverlay').style.display = 'none';
        resetGame();
        gameState = 'playing';
    }

    function triggerGameOver() {
        gameState = 'gameover';
        document.getElementById('overlayTitle').textContent = "GAME OVER";
        document.getElementById('overlayDesc').textContent = "Skor Akhir Kamu: " + score;
        document.getElementById('overlayBtn').textContent = "Main Lagi";
        document.getElementById('messageOverlay').style.display = 'flex';
    }

    function flap() {
        if(gameState === 'playing') {
            bird.velocity = bird.lift;
        }
    }

    function update() {
        if(gameState !== 'playing') return;

        frameCount++;
        bird.velocity += bird.gravity;
        bird.y += bird.velocity;

        // Batas tanah / atas
        if(bird.y + bird.r > 210) {
            bird.y = 210 - bird.r;
            triggerGameOver();
        }
        if(bird.y - bird.r < 0) {
            bird.y = bird.r;
            bird.velocity = 0;
        }

        // Spawn Pipa
        if(frameCount % 100 === 0) {
            let minH = 40;
            let maxH = 120;
            let topH = Math.floor(Math.random() * (maxH - minH + 1)) + minH;
            pipes.push({
                x: 320,
                top: topH,
                bottom: 210 - (topH + pipeGap),
                passed: false
            });
        }

        // Gerak & Cek Tabrakan Pipa
        for(let i = pipes.length - 1; i >= 0; i--) {
            pipes[i].x -= 2;

            // Cek skor
            if(!pipes[i].passed && pipes[i].x + pipeWidth < bird.x) {
                score++;
                document.getElementById('scoreVal').textContent = score;
                pipes[i].passed = true;
            }

            // Tabrakan Kotak Pipa
            if(
                bird.x + bird.r > pipes[i].x && 
                bird.x - bird.r < pipes[i].x + pipeWidth && 
                (bird.y - bird.r < pipes[i].top || bird.y + bird.r > 210 - pipes[i].bottom)
            ) {
                triggerGameOver();
            }

            // Hapus pipa yang keluar layar
            if(pipes[i].x + pipeWidth < 0) {
                pipes.splice(i, 1);
            }
        }
    }

    function draw() {
        // Background langit
        ctx.fillStyle = '#70c5ce';
        ctx.fillRect(0, 0, 320, 240);

        // Gambar Pipa
        pipes.forEach(p => {
            ctx.fillStyle = '#73bf2e';
            ctx.fillRect(p.x, 0, pipeWidth, p.top); // Pipa atas
            ctx.fillRect(p.x, 210 - p.bottom, pipeWidth, p.bottom); // Pipa bawah
            
            // Border pipa
            ctx.strokeStyle = '#558022';
            ctx.lineWidth = 2;
            ctx.strokeRect(p.x, 0, pipeWidth, p.top);
            ctx.strokeRect(p.x, 210 - p.bottom, pipeWidth, p.bottom);
        });

        // Tanah
        ctx.fillStyle = '#ded895';
        ctx.fillRect(0, 210, 320, 30);
        ctx.fillStyle = '#558022';
        ctx.fillRect(0, 210, 320, 6);

        // Gambar Burung (Birdy)
        ctx.fillStyle = '#f8e71c';
        ctx.beginPath();
        ctx.arc(bird.x, bird.y, bird.r, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#b7970f';
        ctx.stroke();

        // Mata burung
        ctx.fillStyle = '#fff';
        ctx.beginPath();
        ctx.arc(bird.x + 4, bird.y - 3, 3, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#000';
        ctx.beginPath();
        ctx.arc(bird.x + 5, bird.y - 3, 1, 0, Math.PI * 2);
        ctx.fill();

        // Paruh burung
        ctx.fillStyle = '#f5a623';
        ctx.beginPath();
        ctx.moveTo(bird.x + bird.r, bird.y - 1);
        ctx.lineTo(bird.x + bird.r + 6, bird.y + 2);
        ctx.lineTo(bird.x + bird.r, bird.y + 5);
        ctx.fill();
    }

    function loop() {
        update();
        draw();
        requestAnimationFrame(loop);
    }

    const flapBtn = document.getElementById('flapBtn');
    flapBtn.addEventListener('touchstart', (e) => { e.preventDefault(); flap(); });
    flapBtn.addEventListener('mousedown', () => flap());

    loop();
})();
</script>
`;
}

async function handler(m, { sock, conn }) {
    const client = sock || conn;

    if (typeof m.react === 'function') await m.react('🐦');

    try {
        const htmlPayload = renderHtmlBirdy();

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "jaka-birdy-game",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `Game Jaka Birdy Dimulai!` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "jaka-birdy-game",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

    } catch (error) {
        console.error('Birdy Game Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler };