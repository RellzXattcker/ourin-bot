// Konfigurasi dasar plugin
const pluginConfig = {
    name: 'blockblast',
    alias: ['block', 'blast', 'tetris', 'puzzle'],
    category: 'games',
    description: 'Main game puzzle Block Blast interaktif langsung di chat',
    usage: '.blockblast',
    example: '.blockblast',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 5,
    isEnabled: true
};

function renderHtmlBlockBlast() {
    return `
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; user-select: none; font-family: 'Segoe UI', Roboto, Helvetica, sans-serif; }
body { margin: 0; background: transparent; color: #f2e9e4; overflow: hidden; }
.game-wrap { width: 100%; max-width: 400px; margin: auto; padding: 10px; }
.game-card {
  background: linear-gradient(180deg, #1a1b26 0%, #16161e 100%);
  border-radius: 18px; overflow: hidden; box-shadow: 0 10px 34px rgba(0,0,0,0.8);
  padding: 16px; border: 1px solid rgba(255,255,255,0.05);
}
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px; }
.title { font-size: 18px; font-weight: 800; color: #bb9af7; letter-spacing: 1px; text-transform: uppercase; }
.score-box { background: rgba(0,0,0,0.3); padding: 4px 12px; border-radius: 12px; font-size: 14px; font-weight: bold; color: #7aa2f7; border: 1px solid rgba(122,162,247,0.3); }
.board-container { width: 100%; aspect-ratio: 1; border-radius: 8px; background: #24283b; padding: 6px; box-shadow: inset 0 4px 10px rgba(0,0,0,0.5); position: relative; }
.board { display: grid; grid-template-columns: repeat(8, 1fr); grid-template-rows: repeat(8, 1fr); gap: 4px; width: 100%; height: 100%; }
.cell { background: #1f2335; border-radius: 4px; transition: background 0.2s, transform 0.1s; }
.cell.filled { background: #7dcfff; box-shadow: 0 0 8px rgba(125,207,255,0.4); border: 1px solid rgba(255,255,255,0.2); }
.cell.hover { background: rgba(125,207,255,0.3); }
.cell.invalid { background: rgba(247,118,142,0.4); }
.shapes-container { display: flex; justify-content: space-around; align-items: center; margin-top: 15px; height: 80px; }
.shape-slot { width: 30%; height: 100%; display: flex; justify-content: center; align-items: center; border-radius: 8px; background: rgba(255,255,255,0.03); cursor: pointer; transition: all 0.2s; border: 2px solid transparent; }
.shape-slot.selected { border-color: #bb9af7; background: rgba(187,154,247,0.1); transform: scale(1.05); }
.shape-slot.empty { opacity: 0; pointer-events: none; }
.mini-grid { display: grid; gap: 2px; }
.mini-cell { width: 12px; height: 12px; background: #9ece6a; border-radius: 2px; }
.mini-cell.empty { background: transparent; }
.overlay { position: absolute; inset: 0; background: rgba(22,22,30,0.85); display: none; flex-direction: column; justify-content: center; align-items: center; z-index: 10; backdrop-filter: blur(3px); border-radius: 8px; }
.overlay-title { font-size: 24px; font-weight: 800; color: #f7768e; margin-bottom: 5px; }
.overlay-score { font-size: 16px; color: #a9b1d6; margin-bottom: 15px; }
.btn { background: #7aa2f7; border: none; color: #1a1b26; padding: 10px 24px; border-radius: 20px; font-size: 14px; font-weight: bold; cursor: pointer; transition: transform 0.2s; }
.btn:active { transform: scale(0.95); }
.info-text { text-align: center; font-size: 10px; color: #565f89; margin-top: 12px; }
</style>
<div class="game-wrap">
  <div class="game-card">
    <div class="header">
      <div class="title">Block Blast</div>
      <div class="score-box">Score: <span id="scoreVal">0</span></div>
    </div>
    <div class="board-container">
      <div id="board" class="board"></div>
      <div id="gameOverOverlay" class="overlay">
        <div class="overlay-title">GAME OVER</div>
        <div class="overlay-score">Final Score: <span id="finalScore">0</span></div>
        <button class="btn" onclick="initGame()">Play Again</button>
      </div>
    </div>
    <div class="shapes-container" id="shapesContainer">
      <div class="shape-slot" id="slot0"></div>
      <div class="shape-slot" id="slot1"></div>
      <div class="shape-slot" id="slot2"></div>
    </div>
    <div class="info-text">Tap balok di bawah, lalu tap kotak di papan untuk meletakkannya.</div>
  </div>
</div>
<script>
(function(){
    const SHAPES = [
        [[1]], // 1x1
        [[1,1]], [[1],[1]], // 1x2
        [[1,1,1]], [[1],[1],[1]], // 1x3
        [[1,1,1,1]], [[1],[1],[1],[1]], // 1x4
        [[1,1],[1,1]], // 2x2
        [[1,0],[1,1]], [[0,1],[1,1]], [[1,1],[1,0]], [[1,1],[0,1]], // L kecil
        [[1,1,1],[1,0,0],[1,0,0]], [[1,1,1],[0,0,1],[0,0,1]], [[0,0,1],[0,0,1],[1,1,1]], [[1,0,0],[1,0,0],[1,1,1]] // L besar
    ];

    const ROWS = 8;
    const COLS = 8;
    let board = [];
    let score = 0;
    let currentShapes = [null, null, null];
    let selectedSlot = -1;
    let gameOver = false;

    const boardEl = document.getElementById('board');
    const scoreEl = document.getElementById('scoreVal');
    const overlay = document.getElementById('gameOverOverlay');
    const finalScoreEl = document.getElementById('finalScore');
    const slots = [document.getElementById('slot0'), document.getElementById('slot1'), document.getElementById('slot2')];

    function createBoard() {
        boardEl.innerHTML = '';
        board = Array(ROWS).fill().map(() => Array(COLS).fill(0));
        for(let r=0; r<ROWS; r++){
            for(let c=0; c<COLS; c++){
                let cell = document.createElement('div');
                cell.className = 'cell';
                cell.dataset.r = r;
                cell.dataset.c = c;
                cell.addEventListener('click', () => handleBoardClick(r, c));
                boardEl.appendChild(cell);
            }
        }
    }

    function renderBoard() {
        for(let r=0; r<ROWS; r++){
            for(let c=0; c<COLS; c++){
                let idx = r * COLS + c;
                let cell = boardEl.children[idx];
                cell.className = 'cell' + (board[r][c] ? ' filled' : '');
            }
        }
    }

    function generateShapes() {
        for(let i=0; i<3; i++){
            if(!currentShapes[i]) {
                const rand = Math.floor(Math.random() * SHAPES.length);
                currentShapes[i] = SHAPES[rand];
            }
        }
        renderShapes();
        checkGameOver();
    }

    function renderShapes() {
        for(let i=0; i<3; i++){
            let slot = slots[i];
            slot.innerHTML = '';
            slot.className = 'shape-slot' + (selectedSlot === i ? ' selected' : '');
            
            if(currentShapes[i]) {
                let shape = currentShapes[i];
                let miniGrid = document.createElement('div');
                miniGrid.className = 'mini-grid';
                miniGrid.style.gridTemplateColumns = \`repeat(\${shape[0].length}, 12px)\`;
                miniGrid.style.gridTemplateRows = \`repeat(\${shape.length}, 12px)\`;
                
                for(let r=0; r<shape.length; r++){
                    for(let c=0; c<shape[0].length; c++){
                        let block = document.createElement('div');
                        block.className = 'mini-cell' + (shape[r][c] ? '' : ' empty');
                        miniGrid.appendChild(block);
                    }
                }
                slot.appendChild(miniGrid);
                slot.onclick = () => selectShape(i);
            } else {
                slot.className = 'shape-slot empty';
                slot.onclick = null;
            }
        }
        
        if(currentShapes.every(s => s === null)) {
            setTimeout(generateShapes, 300);
        }
    }

    function selectShape(idx) {
        if(gameOver) return;
        selectedSlot = selectedSlot === idx ? -1 : idx;
        renderShapes();
    }

    function canPlace(shape, startR, startC) {
        for(let r=0; r<shape.length; r++){
            for(let c=0; c<shape[0].length; c++){
                if(shape[r][c]) {
                    let br = startR + r;
                    let bc = startC + c;
                    if(br >= ROWS || bc >= COLS || board[br][bc]) return false;
                }
            }
        }
        return true;
    }

    function handleBoardClick(r, c) {
        if(gameOver || selectedSlot === -1 || !currentShapes[selectedSlot]) return;
        
        let shape = currentShapes[selectedSlot];
        if(canPlace(shape, r, c)) {
            // Place
            for(let sr=0; sr<shape.length; sr++){
                for(let sc=0; sc<shape[0].length; sc++){
                    if(shape[sr][sc]) board[r+sr][c+sc] = 1;
                }
            }
            
            // Add initial placement score
            score += shape.flat().filter(val => val===1).length * 10;
            
            currentShapes[selectedSlot] = null;
            selectedSlot = -1;
            
            checkClears();
            renderBoard();
            renderShapes();
        } else {
            // Flash red if invalid
            boardEl.children[r * COLS + c].classList.add('invalid');
            setTimeout(() => boardEl.children[r * COLS + c].classList.remove('invalid'), 200);
        }
    }

    function checkClears() {
        let rowsToClear = [];
        let colsToClear = [];

        for(let r=0; r<ROWS; r++){
            if(board[r].every(val => val === 1)) rowsToClear.push(r);
        }
        for(let c=0; c<COLS; c++){
            let full = true;
            for(let r=0; r<ROWS; r++){
                if(board[r][c] === 0) { full = false; break; }
            }
            if(full) colsToClear.push(c);
        }

        let linesCleared = rowsToClear.length + colsToClear.length;
        if(linesCleared > 0) {
            // Combo scoring
            score += linesCleared * 100 + (linesCleared > 1 ? linesCleared * 50 : 0);
            
            rowsToClear.forEach(r => { for(let c=0; c<COLS; c++) board[r][c] = 0; });
            colsToClear.forEach(c => { for(let r=0; r<ROWS; r++) board[r][c] = 0; });
            
            scoreEl.textContent = score;
        }
    }

    function checkGameOver() {
        let possibleMoves = false;
        
        for(let i=0; i<3; i++){
            let shape = currentShapes[i];
            if(shape) {
                for(let r=0; r<ROWS; r++){
                    for(let c=0; c<COLS; c++){
                        if(canPlace(shape, r, c)) {
                            possibleMoves = true;
                            break;
                        }
                    }
                    if(possibleMoves) break;
                }
            }
            if(possibleMoves) break;
        }

        if(!possibleMoves && !currentShapes.every(s => s === null)) {
            gameOver = true;
            finalScoreEl.textContent = score;
            setTimeout(() => overlay.style.display = 'flex', 500);
        }
    }

    window.initGame = function() {
        score = 0;
        scoreEl.textContent = score;
        currentShapes = [null, null, null];
        selectedSlot = -1;
        gameOver = false;
        overlay.style.display = 'none';
        createBoard();
        generateShapes();
    }

    initGame();
})();
</script>
`;
}

// Handler utama bot (Tetap menggunakan standar RelayMessage lu)
async function handler(m, { sock, conn }) {
    const client = sock || conn;

    if (typeof m.react === 'function') await m.react('🧩');

    try {
        const htmlPayload = renderHtmlBlockBlast();

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "kurumi-blockblast-game",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `Game Block Blast Dimulai!` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "kurumi-blockblast-game",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

    } catch (error) {
        console.error('BlockBlast Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler };