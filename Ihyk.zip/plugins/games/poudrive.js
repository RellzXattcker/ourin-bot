const pluginConfig = {
    name: 'poudrive',
    alias: ['pou', 'poucar', 'poudrive', 'hilldrive'],
    category: 'games',
    description: 'Main game Pou Hill Drive (Mobil Naik Bukit) langsung di chat',
    usage: '.poucar',
    example: '.poucar',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 5,
    isEnabled: true
};

function renderHtmlPouDrive() {
    return `
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<style>
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; user-select: none; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
body { margin: 0; background: transparent; color: #fff; overflow: hidden; touch-action: none; }
.game-wrap { width: 100%; max-width: 400px; margin: auto; padding: 10px; }
.game-card {
  background: #1e1e2e;
  border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.8);
  padding: 14px; border: 2px solid #313244;
}
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.title { font-size: 16px; font-weight: 900; color: #f9e2af; letter-spacing: 1px; text-transform: uppercase; }
.info-box { background: #313244; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: bold; color: #a6e3a1; }
.canvas-container { width: 100%; aspect-ratio: 4/3; border-radius: 8px; background: #89b4fa; position: relative; overflow: hidden; border: 2px solid #45475a; }
canvas { display: block; width: 100%; height: 100%; }
.controls { display: flex; justify-content: space-between; margin-top: 12px; gap: 8px; }
.ctrl-btn { flex: 1; background: #313244; border: none; color: #cdd6f4; font-size: 18px; padding: 14px 10px; border-radius: 10px; cursor: pointer; font-weight: bold; text-align: center; }
.ctrl-btn:active { background: #45475a; color: #f9e2af; transform: scale(0.95); }
.overlay { position: absolute; inset: 0; background: rgba(17, 17, 27, 0.85); display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 10; padding: 20px; text-align: center; }
.overlay-title { font-size: 26px; font-weight: 900; color: #f38ba8; margin-bottom: 8px; text-shadow: 0 2px 4px rgba(0,0,0,0.5); }
.overlay-desc { font-size: 13px; color: #bac2de; margin-bottom: 20px; line-height: 1.5; }
.btn { background: #f9e2af; border: none; color: #11111b; padding: 12px 24px; border-radius: 12px; font-size: 15px; font-weight: bold; cursor: pointer; transition: 0.2s; }
.btn:active { transform: scale(0.95); background: #fab387; }
.footer-tip { text-align: center; font-size: 10px; color: #6c7086; margin-top: 12px; }
</style>
<div class="game-wrap">
  <div class="game-card">
    <div class="header">
      <div class="title">Pou Hill Drive</div>
      <div class="info-box">Jarak: <span id="distVal">0</span>m | Koin: <span id="coinVal">0</span></div>
    </div>
    <div class="canvas-container">
      <canvas id="gameCanvas" width="320" height="240"></canvas>
      <div id="messageOverlay" class="overlay">
        <div class="overlay-title" id="overlayTitle">HILL DRIVE</div>
        <div class="overlay-desc" id="overlayDesc">Gas dan Rem untuk menyeimbangkan mobil di udara. Jangan sampai terbalik!</div>
        <button class="btn" id="overlayBtn" onclick="startGame()">Mulai Berkendara</button>
      </div>
    </div>
    <div class="controls">
      <button class="ctrl-btn" id="brakeBtn">BRAKE / KIRI</button>
      <button class="ctrl-btn" id="gasBtn">GAS / KANAN</button>
    </div>
    <div class="footer-tip">Tips: Saat di udara, tekan Rem untuk muter ke kiri, Gas untuk ke kanan.</div>
  </div>
</div>
<script>
(function(){
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    
    let gameState = 'start'; 
    let distance = 0;
    let collectedCoins = 0;

    let car = { x: 100, y: 0, vx: 0, vy: 0, rot: 0 };
    let keys = { gas: false, brake: false };
    let coins = [];
    let nextCoinX = 300;

    // Generator medan perbukitan (Sine waves bertumpuk)
    function getTerrain(x) {
        return Math.sin(x * 0.012) * 35 + Math.sin(x * 0.004) * 45 + 140;
    }

    function resetGame() {
        car = { x: 100, y: 50, vx: 0, vy: 0, rot: 0 };
        coins = [];
        nextCoinX = 300;
        distance = 0;
        collectedCoins = 0;
        document.getElementById('distVal').textContent = distance;
        document.getElementById('coinVal').textContent = collectedCoins;
    }

    window.startGame = function() {
        document.getElementById('messageOverlay').style.display = 'none';
        resetGame();
        gameState = 'playing';
    }

    function triggerGameOver() {
        gameState = 'gameover';
        document.getElementById('overlayTitle').textContent = "TERBALIK!";
        document.getElementById('overlayDesc').textContent = "Jarak: " + distance + "m | Koin: " + collectedCoins;
        document.getElementById('overlayBtn').textContent = "Main Lagi";
        document.getElementById('messageOverlay').style.display = 'flex';
    }

    function update() {
        if(gameState !== 'playing') return;

        // Kontrol Kecepatan (Fisika Horizontal)
        car.vx *= 0.98; // Gesekan tanah/udara
        if(keys.gas) car.vx += 0.18;
        if(keys.brake) car.vx -= 0.18;
        
        // Batas kecepatan mundur biar nggak bug keluar map
        if(car.vx < -3) car.vx = -3;
        car.x += car.vx;
        
        // Update Jarak (Hanya maju)
        if(car.x - 100 > distance * 10) {
            distance = Math.floor((car.x - 100) / 10);
            document.getElementById('distVal').textContent = distance;
        }

        // Hitung ketinggian tanah dan kemiringan
        let groundY = getTerrain(car.x);
        let nextGroundY = getTerrain(car.x + 10);
        let slope = Math.atan2(nextGroundY - groundY, 10);

        // Fisika Vertikal (Gravitasi)
        car.vy += 0.35; 
        car.y += car.vy;

        let grounded = false;
        if(car.y >= groundY - 15) { // 15 adalah jarak sumbu mobil ke tanah
            car.y = groundY - 15;
            car.vy = 0;
            grounded = true;
            
            // Align rotasi ke tanah perlahan
            car.rot += (slope - car.rot) * 0.2;
        } else {
            // Kontrol keseimbangan di udara (Flip mechanics)
            if(keys.gas) car.rot += 0.05;
            if(keys.brake) car.rot -= 0.05;
        }

        // CRASH CONDITION: Terbalik lebih dari ~90 derajat saat menyentuh tanah
        if(grounded && Math.abs(car.rot) > 1.5) {
            triggerGameOver();
        }

        // Spawn Koin
        while(nextCoinX < car.x + 400) {
            let cy = getTerrain(nextCoinX) - 30; // Koin agak melayang
            coins.push({ x: nextCoinX, y: cy, active: true });
            nextCoinX += 120 + Math.random() * 150; // Jarak random antar koin
        }

        // Ambil Koin
        coins.forEach(c => {
            if(c.active && Math.abs(c.x - car.x) < 25 && Math.abs(c.y - car.y) < 25) {
                c.active = false;
                collectedCoins++;
                document.getElementById('coinVal').textContent = collectedCoins;
            }
        });
    }

    function draw() {
        // Hapus background
        ctx.fillStyle = '#89b4fa';
        ctx.fillRect(0, 0, 320, 240);
        
        // Gambar Matahari / Awan hiasan
        ctx.fillStyle = '#f9e2af';
        ctx.beginPath();
        ctx.arc(280 - (car.x * 0.05 % 400), 50, 20, 0, Math.PI * 2);
        ctx.fill();

        let camX = car.x - 100; // Kamera selalu mengikuti mobil di posisi x=100

        // Gambar Tanah (Terrain)
        ctx.fillStyle = '#a6e3a1';
        ctx.beginPath();
        ctx.moveTo(0, 240);
        for(let x = 0; x <= 330; x += 10) {
            let worldX = camX + x;
            ctx.lineTo(x, getTerrain(worldX));
        }
        ctx.lineTo(330, 240);
        ctx.fill();

        // Garis Tanah
        ctx.strokeStyle = '#94e2d5';
        ctx.lineWidth = 4;
        ctx.beginPath();
        for(let x = 0; x <= 330; x += 10) {
            let worldX = camX + x;
            if(x===0) ctx.moveTo(x, getTerrain(worldX));
            else ctx.lineTo(x, getTerrain(worldX));
        }
        ctx.stroke();

        // Gambar Koin
        coins.forEach(c => {
            if(c.active && c.x > camX - 20 && c.x < camX + 340) {
                ctx.fillStyle = '#f9e2af';
                ctx.beginPath();
                ctx.arc(c.x - camX, c.y, 6, 0, Math.PI * 2);
                ctx.fill();
                ctx.strokeStyle = '#fab387';
                ctx.lineWidth = 2;
                ctx.stroke();
            }
        });

        // Gambar Mobil & Pou
        ctx.save();
        ctx.translate(car.x - camX, car.y);
        ctx.rotate(car.rot);
        
        // Sang Pou (Kentang Terbang)
        ctx.fillStyle = '#cba6f7'; // Warna Pou
        ctx.beginPath();
        ctx.arc(0, -10, 10, 0, Math.PI * 2); // Body Pou
        ctx.fill();
        ctx.fillStyle = '#fff'; // Mata
        ctx.beginPath(); ctx.arc(4, -13, 3, 0, Math.PI*2); ctx.fill();
        ctx.beginPath(); ctx.arc(-2, -13, 3, 0, Math.PI*2); ctx.fill();
        ctx.fillStyle = '#000'; // Pupil
        ctx.beginPath(); ctx.arc(5, -13, 1, 0, Math.PI*2); ctx.fill();
        ctx.beginPath(); ctx.arc(-1, -13, 1, 0, Math.PI*2); ctx.fill();

        // Body Mobil
        ctx.fillStyle = '#f38ba8';
        ctx.beginPath();
        ctx.roundRect(-20, -5, 40, 12, 4); // rounded rect polyfill manual
        ctx.fill();
        
        // Roda
        ctx.fillStyle = '#11111b';
        ctx.beginPath(); ctx.arc(-12, 7, 6, 0, Math.PI*2); ctx.fill();
        ctx.beginPath(); ctx.arc(12, 7, 6, 0, Math.PI*2); ctx.fill();
        // Velg
        ctx.fillStyle = '#bac2de';
        ctx.beginPath(); ctx.arc(-12, 7, 2, 0, Math.PI*2); ctx.fill();
        ctx.beginPath(); ctx.arc(12, 7, 2, 0, Math.PI*2); ctx.fill();

        ctx.restore();
    }

    // Polyfill roundRect untuk browser WebView lama
    CanvasRenderingContext2D.prototype.roundRect = CanvasRenderingContext2D.prototype.roundRect || function (x, y, w, h, r) {
        if (w < 2 * r) r = w / 2;
        if (h < 2 * r) r = h / 2;
        this.moveTo(x+r, y);
        this.arcTo(x+w, y,   x+w, y+h, r);
        this.arcTo(x+w, y+h, x,   y+h, r);
        this.arcTo(x,   y+h, x,   y,   r);
        this.arcTo(x,   y,   x+w, y,   r);
        return this;
    }

    function loop() {
        update();
        draw();
        requestAnimationFrame(loop);
    }

    // Input Handling
    const bindBtn = (id, downAction, upAction) => {
        const el = document.getElementById(id);
        if(!el) return;
        el.addEventListener('touchstart', (e) => { e.preventDefault(); downAction(); });
        el.addEventListener('touchend', (e) => { e.preventDefault(); upAction(); });
        el.addEventListener('mousedown', () => downAction());
        el.addEventListener('mouseup', () => upAction());
        el.addEventListener('mouseleave', () => upAction());
    };

    bindBtn('gasBtn', () => keys.gas = true, () => keys.gas = false);
    bindBtn('brakeBtn', () => keys.brake = true, () => keys.brake = false);

    // Initial render
    resetGame();
    draw();
    loop();
})();
</script>
`;
}

async function handler(m, { sock, conn }) {
    const client = sock || conn;

    if (typeof m.react === 'function') await m.react('🚗');

    try {
        const htmlPayload = renderHtmlPouDrive();

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "pou-hilldrive-game",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `Game Pou Hill Drive Dimulai!` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "pou-hilldrive-game",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

    } catch (error) {
        console.error('Pou Drive Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler };