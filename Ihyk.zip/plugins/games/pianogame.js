const pluginConfig = {
    name: 'pianogame',
    alias: ['piano', 'pianotiles', 'musicgame'],
    category: 'games',
    description: 'Main game Piano Tiles (ketuk ubin hitam) langsung di chat',
    usage: '.piano',
    example: '.piano',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 5,
    isEnabled: true
};

function renderHtmlPiano() {
    return `
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<style>
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; user-select: none; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
body { margin: 0; background: transparent; color: #fff; overflow: hidden; touch-action: none; }
.game-wrap { width: 100%; max-width: 400px; margin: auto; padding: 10px; }
.game-card {
  background: #1e1e2e;
  border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.8);
  padding: 14px; border: 2px solid #313244;
}
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.title { font-size: 16px; font-weight: 900; color: #89b4fa; letter-spacing: 1px; text-transform: uppercase; }
.info-box { background: #313244; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: bold; color: #a6e3a1; }
.canvas-container { width: 100%; aspect-ratio: 4/3; border-radius: 8px; background: #11111b; position: relative; overflow: hidden; border: 2px solid #45475a; }
canvas { display: block; width: 100%; height: 100%; }
.overlay { position: absolute; inset: 0; background: rgba(17, 17, 27, 0.88); display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 10; padding: 20px; text-align: center; }
.overlay-title { font-size: 24px; font-weight: 900; color: #89b4fa; margin-bottom: 8px; text-shadow: 0 2px 4px rgba(0,0,0,0.5); }
.overlay-desc { font-size: 13px; color: #bac2de; margin-bottom: 20px; line-height: 1.5; }
.btn { background: #89b4fa; border: none; color: #11111b; padding: 12px 24px; border-radius: 12px; font-size: 15px; font-weight: bold; cursor: pointer; transition: 0.2s; }
.btn:active { transform: scale(0.95); background: #b4befe; }
.footer-tip { text-align: center; font-size: 10px; color: #6c7086; margin-top: 12px; }
</style>
<div class="game-wrap">
  <div class="game-card">
    <div class="header">
      <div class="title">Jaka Piano Tiles</div>
      <div class="info-box">Skor: <span id="scoreVal">0</span></div>
    </div>
    <div class="canvas-container">
      <canvas id="gameCanvas" width="320" height="240"></canvas>
      <div id="messageOverlay" class="overlay">
        <div class="overlay-title" id="overlayTitle">PIANO TILES</div>
        <div class="overlay-desc" id="overlayDesc">Ketuk ubin hitam yang berjalan ke bawah. Jangan sampai ada yang terlewat!</div>
        <button class="btn" id="overlayBtn" onclick="startGame()">Mulai Main</button>
      </div>
    </div>
    <div class="footer-tip">Ketuk langsung pada ubin hitam di layar canvas!</div>
  </div>
</div>
<script>
(function(){
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    
    let gameState = 'start'; 
    let score = 0;
    let speed = 2.0;
    let tiles = [];
    let spawnTimer = 0;

    const cols = 4;
    const colWidth = 320 / cols;

    function resetGame() {
        score = 0;
        speed = 2.0;
        tiles = [];
        spawnTimer = 0;
        document.getElementById('scoreVal').textContent = "0";
    }

    window.startGame = function() {
        document.getElementById('messageOverlay').style.display = 'none';
        resetGame();
        gameState = 'playing';
    }

    function triggerGameOver() {
        gameState = 'gameover';
        document.getElementById('overlayTitle').textContent = "GAME OVER";
        document.getElementById('overlayTitle').style.color = "#f38ba8";
        document.getElementById('overlayDesc').textContent = "Skor Akhir Kamu: " + score;
        document.getElementById('overlayBtn').textContent = "Main Lagi";
        document.getElementById('messageOverlay').style.display = 'flex';
    }

    function update() {
        if(gameState !== 'playing') return;

        spawnTimer++;
        speed += 0.001; // Kecepatan bertambah seiring waktu

        // Spawn ubin baru secara berkala
        if(spawnTimer > Math.max(25, 65 - Math.floor(score * 0.5))) {
            spawnTimer = 0;
            let col = Math.floor(Math.random() * cols);
            tiles.push({ col: col, y: -60, h: 60, clicked: false });
        }

        // Gerakkan ubin ke bawah
        for(let i = tiles.length - 1; i >= 0; i--) {
            tiles[i].y += speed;

            // Cek apakah ubin lewat batas bawah (Game Over)
            if(!tiles[i].clicked && tiles[i].y > 240) {
                triggerGameOver();
            }

            // Hapus ubin yang sudah lewat jauh di bawah
            if(tiles[i].y > 300) {
                tiles.splice(i, 1);
            }
        }
    }

    function draw() {
        // Background Gelap Piano
        ctx.fillStyle = '#11111b';
        ctx.fillRect(0, 0, 320, 240);

        // Gambar Garis Pembatas 4 Kolom
        ctx.strokeStyle = '#313244';
        ctx.lineWidth = 1;
        for(let i = 1; i < cols; i++) {
            ctx.beginPath();
            ctx.moveTo(i * colWidth, 0);
            ctx.lineTo(i * colWidth, 240);
            ctx.stroke();
        }

        // Gambar Ubin Piano
        tiles.forEach(t => {
            let tx = t.col * colWidth;
            if(!t.clicked) {
                ctx.fillStyle = '#181825'; // Hitam ubin elegan
                ctx.fillRect(tx + 2, t.y, colWidth - 4, t.h);
                // Efek kilau atas ubin
                ctx.fillStyle = '#45475a';
                ctx.fillRect(tx + 2, t.y, colWidth - 4, 6);
            } else {
                // Ubin yang sudah diketuk berubah jadi hijau terang
                ctx.fillStyle = '#a6e3a1';
                ctx.fillRect(tx + 2, t.y, colWidth - 4, t.h);
            }
        });
    }

    function loop() {
        update();
        draw();
        requestAnimationFrame(loop);
    }

    // Interaksi Sentuh / Klik langsung di dalam area Canvas
    canvas.addEventListener('pointerdown', (e) => {
        if(gameState !== 'playing') return;

        const rect = canvas.getBoundingClientRect();
        // Hitung koordinat klik relatif terhadap ukuran canvas 320x240
        const clickX = (e.clientX - rect.left) * (320 / rect.width);
        const clickY = (e.clientY - rect.top) * (240 / rect.height);

        let hit = false;
        for(let i = tiles.length - 1; i >= 0; i--) {
            let t = tiles[i];
            let tx = t.col * colWidth;

            // Cek apakah ketukan berada di dalam area ubin hitam tersebut
            if(!t.clicked && clickX >= tx && clickX <= tx + colWidth && clickY >= t.y && clickY <= t.y + t.h) {
                t.clicked = true;
                score++;
                document.getElementById('scoreVal').textContent = score;
                hit = true;
                break;
            }
        }

        // Kalau mengetuk area kosong yang tidak ada ubin hitamnya, langsung Game Over!
        if(!hit) {
            // Opsional: aktifkan kalau mau mode strict, tapi dibiarkan aman juga boleh.
        }
    });

    // Initial render
    resetGame();
    draw();
    loop();
})();
</script>
`;
}

async function handler(m, { sock, conn }) {
    const client = sock || conn;

    if (typeof m.react === 'function') await m.react('🎹');

    try {
        const htmlPayload = renderHtmlPiano();

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "jaka-piano-game",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `Game Jaka Piano Tiles Dimulai!` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "jaka-piano-game",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

    } catch (error) {
        console.error('Piano Game Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler };