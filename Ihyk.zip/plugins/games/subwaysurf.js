const pluginConfig = {
    name: 'subwaysurf',
    alias: ['subway', 'surf', 'subwaysurfers'],
    category: 'games',
    description: 'Main game endless runner ala Subway Surfers dengan mekanik pseudo-3D di chat',
    usage: '.subway',
    example: '.subway',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 5,
    isEnabled: true
};

function renderHtmlSubwaySurf() {
    return `
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<style>
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; user-select: none; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
body { margin: 0; background: transparent; color: #fff; overflow: hidden; touch-action: none; }
.game-wrap { width: 100%; max-width: 400px; margin: auto; padding: 10px; }
.game-card {
  background: #1e1e2e;
  border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.8);
  padding: 14px; border: 2px solid #313244;
}
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.title { font-size: 16px; font-weight: 900; color: #f9e2af; letter-spacing: 1px; text-transform: uppercase; }
.info-box { background: #313244; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: bold; color: #a6e3a1; }
.canvas-container { width: 100%; aspect-ratio: 4/3; border-radius: 8px; background: #87CEEB; position: relative; overflow: hidden; border: 2px solid #45475a; }
canvas { display: block; width: 100%; height: 100%; }
.controls { display: flex; justify-content: space-between; margin-top: 12px; gap: 8px; }
.ctrl-btn { flex: 1; background: #313244; border: none; color: #cdd6f4; font-size: 18px; padding: 14px 10px; border-radius: 10px; cursor: pointer; font-weight: bold; text-align: center; }
.ctrl-btn:active { background: #45475a; color: #f9e2af; transform: scale(0.95); }
.overlay { position: absolute; inset: 0; background: rgba(17, 17, 27, 0.85); display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 10; padding: 20px; text-align: center; }
.overlay-title { font-size: 24px; font-weight: 900; color: #f9e2af; margin-bottom: 8px; text-shadow: 0 2px 4px rgba(0,0,0,0.5); }
.overlay-desc { font-size: 13px; color: #bac2de; margin-bottom: 20px; line-height: 1.5; }
.btn { background: #f9e2af; border: none; color: #11111b; padding: 12px 24px; border-radius: 12px; font-size: 15px; font-weight: bold; cursor: pointer; transition: 0.2s; }
.btn:active { transform: scale(0.95); background: #fab387; }
.footer-tip { text-align: center; font-size: 10px; color: #6c7086; margin-top: 12px; }
</style>
<div class="game-wrap">
  <div class="game-card">
    <div class="header">
      <div class="title">Jaka Subway Surf</div>
      <div class="info-box">Skor: <span id="distVal">0</span> | Koin: <span id="coinVal">0</span></div>
    </div>
    <div class="canvas-container">
      <canvas id="gameCanvas" width="320" height="240"></canvas>
      <div id="messageOverlay" class="overlay">
        <div class="overlay-title" id="overlayTitle">SUBWAY SURF</div>
        <div class="overlay-desc" id="overlayDesc">Hindari Kereta (Geser) dan Pembatas (Lompat). Kumpulkan Koin!</div>
        <button class="btn" id="overlayBtn" onclick="startGame()">Mulai Lari</button>
      </div>
    </div>
    <div class="controls">
      <button class="ctrl-btn" id="leftBtn">◀</button>
      <button class="ctrl-btn" id="jumpBtn">▲</button>
      <button class="ctrl-btn" id="rightBtn">▶</button>
    </div>
    <div class="footer-tip">Gunakan 3 Jalur. Hindari rintangan merah!</div>
  </div>
</div>
<script>
(function(){
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    
    let gameState = 'start'; 
    let frames = 0;
    let speed = 1.5;
    let distance = 0;
    let coins = 0;

    // Player State
    // lane: -1 (Kiri), 0 (Tengah), 1 (Kanan)
    let player = { lane: 0, targetLane: 0, y: 0, vy: 0 };
    let objects = [];

    function resetGame() {
        frames = 0;
        speed = 1.5;
        distance = 0;
        coins = 0;
        player = { lane: 0, targetLane: 0, y: 0, vy: 0 };
        objects = [];
        document.getElementById('distVal').textContent = "0";
        document.getElementById('coinVal').textContent = "0";
    }

    window.startGame = function() {
        document.getElementById('messageOverlay').style.display = 'none';
        resetGame();
        gameState = 'playing';
    }

    function triggerGameOver() {
        gameState = 'gameover';
        document.getElementById('overlayTitle').textContent = "TERTANGKAP!";
        document.getElementById('overlayTitle').style.color = "#f38ba8";
        document.getElementById('overlayDesc').textContent = "Jarak: " + Math.floor(distance) + " | Koin: " + coins;
        document.getElementById('overlayBtn').textContent = "Main Lagi";
        document.getElementById('messageOverlay').style.display = 'flex';
    }

    function update() {
        if(gameState !== 'playing') return;
        frames++;

        // Smooth Lane Transition (Interpolasi)
        if(player.lane < player.targetLane) player.lane += 0.2;
        if(player.lane > player.targetLane) player.lane -= 0.2;
        if(Math.abs(player.lane - player.targetLane) < 0.1) player.lane = player.targetLane;

        // Fisika Lompatan
        if(player.y > 0 || player.vy !== 0) {
            player.y += player.vy;
            player.vy -= 1.4; // Gravitasi
            if(player.y <= 0) {
                player.y = 0;
                player.vy = 0;
            }
        }

        // Penambahan Kecepatan Bertahap
        speed += 0.0005;
        distance += speed * 0.1;
        document.getElementById('distVal').textContent = Math.floor(distance);

        // Spawn Sistem Rintangan & Koin
        let spawnRate = Math.max(15, Math.floor(50 / speed));
        if(frames % spawnRate === 0) {
            let lane = Math.floor(Math.random() * 3) - 1; // -1, 0, 1
            let rand = Math.random();
            
            // 30% Kereta, 30% Pembatas (Barrier), 40% Koin
            let type = rand < 0.3 ? 'train' : (rand < 0.6 ? 'barrier' : 'coin');
            
            objects.push({ lane: lane, z: 100, type: type });

            // Kalau muncul kereta, coba spawn koin di jalur lain
            if(type === 'train' && Math.random() < 0.6) {
                let safeLane = lane === 0 ? (Math.random() < 0.5 ? -1 : 1) : 0;
                objects.push({ lane: safeLane, z: 100, type: 'coin' });
            }
        }

        // Update Objek dan Deteksi Tabrakan
        for(let i = objects.length - 1; i >= 0; i--) {
            let obj = objects[i];
            obj.z -= speed;

            // Logika Tabrakan (Cek saat objek dekat dengan posisi Z pemain)
            if(obj.z < 15 && obj.z > 5 && Math.abs(player.lane - obj.lane) < 0.5) {
                if(obj.type === 'coin') {
                    if(!obj.collected) {
                        obj.collected = true;
                        coins++;
                        document.getElementById('coinVal').textContent = coins;
                    }
                } else if(obj.type === 'train') {
                    triggerGameOver();
                } else if(obj.type === 'barrier') {
                    if(player.y < 25) triggerGameOver(); // Kena jika lompatan kurang tinggi
                }
            }

            // Hapus jika sudah lewat kamera
            if(obj.z < 0) objects.splice(i, 1);
        }
    }

    function draw() {
        // Latar Belakang & Langit
        ctx.fillStyle = '#87CEEB';
        ctx.fillRect(0, 0, 320, 80);
        
        // Matahari/Bulan
        ctx.fillStyle = '#f9e2af';
        ctx.beginPath(); ctx.arc(260, 40, 20, 0, Math.PI*2); ctx.fill();

        // Rumput Kiri Kanan
        ctx.fillStyle = '#a6e3a1';
        ctx.fillRect(0, 80, 320, 160);

        // Rel Kereta (Tengah)
        ctx.fillStyle = '#95a5a6';
        ctx.beginPath();
        ctx.moveTo(160, 80); // Titik tengah horizon (Vanishing point)
        ctx.lineTo(30, 240); // Sudut kiri bawah
        ctx.lineTo(290, 240); // Sudut kanan bawah
        ctx.fill();

        // Garis Pembatas Jalur
        ctx.strokeStyle = '#ecf0f1';
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(160, 80); ctx.lineTo(116, 240); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(160, 80); ctx.lineTo(204, 240); ctx.stroke();

        // Urutkan objek dari Z terbesar ke terkecil (Jauh ke Dekat untuk ilusi 3D)
        objects.sort((a, b) => b.z - a.z);

        // Render Objek Pseudo-3D
        objects.forEach(obj => {
            if(obj.collected) return;
            
            // Rumus Scale Perspective
            let scale = (100 - obj.z) / 100;
            // 90 adalah jarak sebaran X di bagian bawah layar
            let sx = 160 + (obj.lane * 90 * scale);
            let sy = 80 + (160 * scale); 
            
            let w = 45 * scale; // Lebar objek menyesuaikan scale

            if(obj.type === 'train') {
                let h = 70 * scale;
                ctx.fillStyle = '#e74c3c'; // Merah kereta
                ctx.fillRect(sx - w/2, sy - h, w, h);
                // Kaca Kereta
                ctx.fillStyle = '#11111b';
                ctx.fillRect(sx - w/3, sy - h + 6*scale, w/1.5, h/3.5);
                // Lampu
                ctx.fillStyle = '#f1c40f';
                ctx.fillRect(sx - w/3, sy - h/4, w/4, h/5);
                ctx.fillRect(sx + w/12, sy - h/4, w/4, h/5);

            } else if(obj.type === 'barrier') {
                let h = 25 * scale;
                ctx.fillStyle = '#e67e22';
                ctx.fillRect(sx - w/2, sy - h, w, h);
                // Motif Garis Pembatas
                ctx.fillStyle = '#f1c40f';
                ctx.fillRect(sx - w/2, sy - h, w/4, h);
                ctx.fillRect(sx - w/8, sy - h, w/4, h);
                ctx.fillRect(sx + w/4, sy - h, w/4, h);

            } else if(obj.type === 'coin') {
                let r = 12 * scale;
                ctx.fillStyle = '#f1c40f';
                ctx.beginPath();
                ctx.arc(sx, sy - 15 * scale, r, 0, Math.PI*2);
                ctx.fill();
                // Bolong Koin
                ctx.fillStyle = '#d4ac0d';
                ctx.beginPath();
                ctx.arc(sx, sy - 15 * scale, r/2, 0, Math.PI*2);
                ctx.fill();
            }
        });

        // Render Pemain
        // Pemain dikunci di z = 10 (cukup dekat dengan kamera)
        let pScale = (100 - 10) / 100; // = 0.9
        let px = 160 + (player.lane * 90 * pScale);
        let py = 80 + (160 * pScale) - (player.y * pScale);
        
        let pw = 30 * pScale;
        let ph = 50 * pScale;

        // Bayangan Pemain
        ctx.fillStyle = 'rgba(0,0,0,0.3)';
        ctx.beginPath();
        ctx.ellipse(px, 80 + 160*pScale, pw/1.2, pw/4, 0, 0, Math.PI*2);
        ctx.fill();

        // Badan
        ctx.fillStyle = '#3498db'; // Baju biru
        ctx.fillRect(px - pw/2, py - ph, pw, ph);
        // Kepala
        ctx.fillStyle = '#f1c27d'; // Kulit
        ctx.beginPath(); ctx.arc(px, py - ph - 8*pScale, 14*pScale, 0, Math.PI*2); ctx.fill();
        // Topi
        ctx.fillStyle = '#e74c3c';
        ctx.beginPath(); ctx.arc(px, py - ph - 11*pScale, 14*pScale, Math.PI, 0); ctx.fill();
        // Tas (Ransel)
        ctx.fillStyle = '#8e44ad';
        ctx.fillRect(px - pw/2.5, py - ph/1.2, pw/1.2, ph/2);
    }

    function loop() {
        update();
        draw();
        requestAnimationFrame(loop);
    }

    // Sistem Kontrol
    const bindBtn = (id, action) => {
        const el = document.getElementById(id);
        if(!el) return;
        el.addEventListener('touchstart', (e) => { e.preventDefault(); action(); });
        el.addEventListener('mousedown', () => action());
    };

    bindBtn('leftBtn', () => { if(gameState === 'playing') player.targetLane = Math.max(-1, player.targetLane - 1); });
    bindBtn('rightBtn', () => { if(gameState === 'playing') player.targetLane = Math.min(1, player.targetLane + 1); });
    bindBtn('jumpBtn', () => { if(gameState === 'playing' && player.y === 0) player.vy = 16.5; }); // Lompat tinggi

    // Keyboard support buat testing kalau dimainkan di desktop
    window.addEventListener('keydown', (e) => {
        if(gameState !== 'playing') return;
        if(e.key === 'ArrowLeft' || e.key === 'a') player.targetLane = Math.max(-1, player.targetLane - 1);
        if(e.key === 'ArrowRight' || e.key === 'd') player.targetLane = Math.min(1, player.targetLane + 1);
        if((e.key === 'ArrowUp' || e.key === 'w' || e.key === ' ') && player.y === 0) player.vy = 16.5;
    });

    // Initial render awal
    resetGame();
    draw();
    loop();
})();
</script>
`;
}

async function handler(m, { sock, conn }) {
    const client = sock || conn;

    if (typeof m.react === 'function') await m.react('🛹');

    try {
        const htmlPayload = renderHtmlSubwaySurf();

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "jaka-subwaysurf-game",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `Game Subway Surf Dimulai!` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "jaka-subwaysurf-game",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

    } catch (error) {
        console.error('Subway Surf Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler };