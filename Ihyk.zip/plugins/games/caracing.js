const pluginConfig = {
    name: 'caracing',
    alias: ['car', 'racing', 'mobilbalap'],
    category: 'games',
    description: 'Main game balap mobil arcade klasik rasio vertikal 9:16 langsung di chat',
    usage: '.car',
    example: '.car',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 5,
    isEnabled: true
};

function renderHtmlCarRacing() {
    return `
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<style>
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; user-select: none; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
body { margin: 0; background: transparent; color: #fff; overflow: hidden; touch-action: none; }
.game-wrap { width: 100%; max-width: 360px; margin: auto; padding: 10px; }
.game-card {
  background: #1e1e2e;
  border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.8);
  padding: 14px; border: 2px solid #313244;
}
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.title { font-size: 15px; font-weight: 900; color: #89b4fa; letter-spacing: 1px; text-transform: uppercase; }
.info-box { background: #313244; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: bold; color: #a6e3a1; }
.canvas-container { width: 100%; aspect-ratio: 9/16; border-radius: 8px; background: #313244; position: relative; overflow: hidden; border: 2px solid #45475a; }
canvas { display: block; width: 100%; height: 100%; }
.controls { display: flex; justify-content: space-between; margin-top: 12px; gap: 10px; }
.ctrl-btn { flex: 1; background: #313244; border: none; color: #cdd6f4; font-size: 20px; padding: 14px; border-radius: 10px; cursor: pointer; font-weight: bold; text-align: center; }
.ctrl-btn:active { background: #45475a; color: #89b4fa; transform: scale(0.95); }
.overlay { position: absolute; inset: 0; background: rgba(17, 17, 27, 0.88); display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 10; padding: 20px; text-align: center; }
.overlay-title { font-size: 24px; font-weight: 900; color: #89b4fa; margin-bottom: 8px; text-shadow: 0 2px 4px rgba(0,0,0,0.5); }
.overlay-desc { font-size: 13px; color: #bac2de; margin-bottom: 20px; line-height: 1.4; }
.btn { background: #89b4fa; border: none; color: #11111b; padding: 12px 24px; border-radius: 12px; font-size: 15px; font-weight: bold; cursor: pointer; transition: 0.2s; }
.btn:active { transform: scale(0.95); background: #b4befe; }
.footer-tip { text-align: center; font-size: 10px; color: #6c7086; margin-top: 10px; }
</style>
<div class="game-wrap">
  <div class="game-card">
    <div class="header">
      <div class="title">Jaka Car Racing</div>
      <div class="info-box">Skor: <span id="scoreVal">0</span></div>
    </div>
    <div class="canvas-container">
      <canvas id="gameCanvas" width="180" height="320"></canvas>
      <div id="messageOverlay" class="overlay">
        <div class="overlay-title" id="overlayTitle">CAR RACING</div>
        <div class="overlay-desc" id="overlayDesc">Hindari mobil lawan yang datang dari arah berlawanan!</div>
        <button class="btn" id="overlayBtn" onclick="startGame()">Mulai Balapan</button>
      </div>
    </div>
    <div class="controls">
      <button class="ctrl-btn" id="leftBtn">◀ KIRI</button>
      <button class="ctrl-btn" id="rightBtn">KANAN ▶</button>
    </div>
    <div class="footer-tip">Gunakan tombol Kiri dan Kanan untuk berpindah jalur jalan raya.</div>
  </div>
</div>
<script>
(function(){
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    
    let gameState = 'start'; 
    let score = 0;
    let speed = 2.5;
    let roadAnim = 0;

    // Posisi mobil pemain (3 Jalur: X = 45, 90, 135)
    let lanes = [45, 90, 135];
    let player = { laneIndex: 1, y: 260, w: 20, h: 36 };
    let obstacles = [];
    let spawnTimer = 0;

    function resetGame() {
        score = 0;
        speed = 2.5;
        player.laneIndex = 1;
        obstacles = [];
        spawnTimer = 0;
        document.getElementById('scoreVal').textContent = "0";
    }

    window.startGame = function() {
        document.getElementById('messageOverlay').style.display = 'none';
        resetGame();
        gameState = 'playing';
    }

    function triggerGameOver() {
        gameState = 'gameover';
        document.getElementById('overlayTitle').textContent = "CRASH!";
        document.getElementById('overlayTitle').style.color = "#f38ba8";
        document.getElementById('overlayDesc').textContent = "Skor Akhir Kamu: " + Math.floor(score);
        document.getElementById('overlayBtn').textContent = "Main Lagi";
        document.getElementById('messageOverlay').style.display = 'flex';
    }

    function update() {
        if(gameState !== 'playing') return;

        speed += 0.001; // Kecepatan mobil meningkat bertahap
        score += speed * 0.1;
        document.getElementById('scoreVal').textContent = Math.floor(score);

        roadAnim = (roadAnim + speed) % 40;

        spawnTimer++;
        // Spawn mobil musuh secara berkala
        if(spawnTimer > Math.max(25, 60 - Math.floor(speed * 3))) {
            spawnTimer = 0;
            let lIdx = Math.floor(Math.random() * 3);
            obstacles.push({ laneIndex: lIdx, y: -50, w: 20, h: 36, color: '#f38ba8' });
        }

        // Update posisi rintangan/musuh
        for(let i = obstacles.length - 1; i >= 0; i--) {
            obstacles[i].y += speed * 1.2;

            // Deteksi Tabrakan (AABB Collision)
            let pX = lanes[player.laneIndex] - player.w/2;
            let oX = lanes[obstacles[i].laneIndex] - obstacles[i].w/2;

            if(pX < oX + obstacles[i].w && pX + player.w > oX &&
               player.y < obstacles[i].y + obstacles[i].h && player.y + player.h > obstacles[i].y) {
                triggerGameOver();
            }

            // Hapus rintangan yang sudah lewat bawah layar
            if(obstacles[i].y > 340) {
                obstacles.splice(i, 1);
            }
        }
    }

    function draw() {
        // Rumput Kiri Kanan
        ctx.fillStyle = '#a6e3a1';
        ctx.fillRect(0, 0, 180, 320);

        // Jalan Raya (Lebar 120px di tengah, dari x=30 sampai x=150)
        ctx.fillStyle = '#313244';
        ctx.fillRect(30, 0, 120, 320);

        // Garis Tepi Jalan
        ctx.fillStyle = '#f9e2af';
        ctx.fillRect(30, 0, 4, 320);
        ctx.fillRect(146, 0, 4, 320);

        // Garis Putus-putus Jalur Tengah
        ctx.strokeStyle = '#cdd6f4';
        ctx.lineWidth = 2;
        ctx.setLineDash([15, 15]);
        ctx.lineDashOffset = -roadAnim;
        
        ctx.beginPath(); ctx.moveTo(70, 0); ctx.lineTo(70, 320); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(110, 0); ctx.lineTo(110, 320); ctx.stroke();
        ctx.setLineDash([]); // Reset line dash

        // Gambar Mobil Musuh
        obstacles.forEach(obs => {
            let ox = lanes[obs.laneIndex] - obs.w/2;
            ctx.fillStyle = obs.color;
            ctx.beginPath(); ctx.roundRect(ox, obs.y, obs.w, obs.h, 4); ctx.fill();
            // Kaca & Lampu Musuh
            ctx.fillStyle = '#11111b';
            ctx.fillRect(ox + 3, obs.y + 6, obs.w - 6, 8);
            ctx.fillStyle = '#f9e2af';
            ctx.fillRect(ox + 2, obs.y + obs.h - 4, 3, 3);
            ctx.fillRect(ox + obs.w - 5, obs.y + obs.h - 4, 3, 3);
        });

        // Gambar Mobil Pemain
        let px = lanes[player.laneIndex] - player.w/2;
        ctx.fillStyle = '#89b4fa';
        ctx.beginPath(); ctx.roundRect(px, player.y, player.w, player.h, 4); ctx.fill();
        // Kaca & Lampu Depan Pemain
        ctx.fillStyle = '#11111b';
        ctx.fillRect(px + 3, player.y + 22, player.w - 6, 8);
        ctx.fillStyle = '#fab387';
        ctx.fillRect(px + 2, player.y + 2, 3, 3);
        ctx.fillRect(px + player.w - 5, player.y + 2, 3, 3);
    }

    // Polyfill roundRect untuk kompatibilitas canvas
    CanvasRenderingContext2D.prototype.roundRect = CanvasRenderingContext2D.prototype.roundRect || function (x, y, w, h, r) {
        if (w < 2 * r) r = w / 2;
        if (h < 2 * r) r = h / 2;
        this.moveTo(x+r, y);
        this.arcTo(x+w, y,   x+w, y+h, r);
        this.arcTo(x+w, y+h, x,   y+h, r);
        this.arcTo(x,   y+h, x,   y,   r);
        this.arcTo(x,   y,   x+w, y,   r);
        return this;
    }

    function loop() {
        update();
        draw();
        requestAnimationFrame(loop);
    }

    // Kontrol Tombol Kiri & Kanan
    const bindBtn = (id, action) => {
        const el = document.getElementById(id);
        if(!el) return;
        el.addEventListener('touchstart', (e) => { e.preventDefault(); action(); });
        el.addEventListener('mousedown', () => action());
    };

    bindBtn('leftBtn', () => { if(gameState === 'playing') player.laneIndex = Math.max(0, player.laneIndex - 1); });
    bindBtn('rightBtn', () => { if(gameState === 'playing') player.laneIndex = Math.min(2, player.laneIndex + 1); });

    // Keyboard support untuk testing desktop
    window.addEventListener('keydown', (e) => {
        if(gameState !== 'playing') return;
        if(e.key === 'ArrowLeft' || e.key === 'a') player.laneIndex = Math.max(0, player.laneIndex - 1);
        if(e.key === 'ArrowRight' || e.key === 'd') player.laneIndex = Math.min(2, player.laneIndex + 1);
    });

    resetGame();
    draw();
    loop();
})();
</script>
`;
}

async function handler(m, { sock, conn }) {
    const client = sock || conn;

    if (typeof m.react === 'function') await m.react('🏎️');

    try {
        const htmlPayload = renderHtmlCarRacing();

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "jaka-caracing-game",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `Game Jaka Car Racing Dimulai!` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "jaka-caracing-game",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

    } catch (error) {
        console.error('Car Racing Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler };