const pluginConfig = {
    name: 'leveldevil',
    alias: ['devil', 'leveldevil', 'trollgame'],
    category: 'games',
    description: 'Main game platformer jebakan Level Devil 2D langsung di chat',
    usage: '.leveldevil',
    example: '.leveldevil',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 5,
    isEnabled: true
};

function renderHtmlLevelDevil() {
    return `
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<style>
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; user-select: none; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
body { margin: 0; background: transparent; color: #fff; overflow: hidden; touch-action: none; }
.game-wrap { width: 100%; max-width: 400px; margin: auto; padding: 10px; }
.game-card {
  background: #1e1e2e;
  border-radius: 16px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.8);
  padding: 14px; border: 2px solid #313244;
}
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.title { font-size: 16px; font-weight: 900; color: #f38ba8; letter-spacing: 1px; text-transform: uppercase; }
.info-box { background: #313244; padding: 4px 10px; border-radius: 6px; font-size: 12px; font-weight: bold; color: #fab387; }
.canvas-container { width: 100%; aspect-ratio: 4/3; border-radius: 8px; background: #11111b; position: relative; overflow: hidden; border: 2px solid #45475a; }
canvas { display: block; width: 100%; height: 100%; background: #11111b; }
.controls { display: flex; justify-content: space-between; margin-top: 12px; gap: 8px; }
.ctrl-btn { flex: 1; background: #313244; border: none; color: #cdd6f4; font-size: 20px; padding: 14px 10px; border-radius: 10px; cursor: pointer; font-weight: bold; text-align: center; }
.ctrl-btn:active { background: #45475a; color: #f38ba8; transform: scale(0.95); }
.overlay { position: absolute; inset: 0; background: rgba(17, 17, 27, 0.92); display: flex; flex-direction: column; justify-content: center; align-items: center; z-index: 10; padding: 20px; text-align: center; }
.overlay-title { font-size: 24px; font-weight: 900; color: #f38ba8; margin-bottom: 8px; text-shadow: 0 2px 4px rgba(0,0,0,0.5); }
.overlay-desc { font-size: 13px; color: #bac2de; margin-bottom: 20px; line-height: 1.5; }
.btn { background: #a6e3a1; border: none; color: #11111b; padding: 12px 24px; border-radius: 12px; font-size: 15px; font-weight: bold; cursor: pointer; transition: 0.2s; }
.btn:active { transform: scale(0.95); background: #94e2d5; }
.footer-tip { text-align: center; font-size: 10px; color: #6c7086; margin-top: 12px; }
</style>
<div class="game-wrap">
  <div class="game-card">
    <div class="header">
      <div class="title">Level Devil</div>
      <div class="info-box">Level: <span id="lvlVal">1</span> | Death: <span id="deathVal">0</span></div>
    </div>
    <div class="canvas-container">
      <canvas id="gameCanvas" width="320" height="240"></canvas>
      <div id="messageOverlay" class="overlay">
        <div class="overlay-title" id="overlayTitle">LEVEL DEVIL</div>
        <div class="overlay-desc" id="overlayDesc">Awas jebakan! Selesaikan level tanpa mati.</div>
        <button class="btn" id="overlayBtn" onclick="startGame()">Mulai Main</button>
      </div>
    </div>
    <div class="controls">
      <button class="ctrl-btn" id="leftBtn">◀</button>
      <button class="ctrl-btn" id="jumpBtn">▲</button>
      <button class="ctrl-btn" id="rightBtn">▶</button>
    </div>
    <div class="footer-tip">Game Penuh Jebakan: Jangan percaya apa yang kamu lihat!</div>
  </div>
</div>
<script>
(function(){
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    
    let deaths = 0;
    let currentLevel = 1;
    let gameState = 'start'; 

    let player = {
        x: 20, y: 170, w: 14, h: 14,
        vx: 0, vy: 0, speed: 2.5, jumpPower: -7.5,
        grounded: false
    };

    let keys = { left: false, right: false, jump: false };

    // Master Data Level (Blueprint Jebakan)
    const levelBlueprints = {
        1: {
            spawn: {x: 20, y: 170},
            goal: {x: 270, y: 170, w: 20, h: 20, moving: false},
            platforms: [
                {x: 0, y: 200, w: 130, h: 40, type: 'normal'},
                {x: 130, y: 200, w: 70, h: 40, type: 'fall', triggered: false}, // Jebakan lantai jatuh
                {x: 200, y: 200, w: 120, h: 40, type: 'normal'}
            ],
            spikes: [
                {x: 155, y: 200, w: 20, h: 10, hidden: true, triggerDist: 40} // Duri ngagetin
            ]
        },
        2: {
            spawn: {x: 20, y: 170},
            goal: {x: 280, y: 60, w: 20, h: 20, moving: true, originX: 280}, // Pintu kabur
            platforms: [
                {x: 0, y: 200, w: 110, h: 40, type: 'normal'},
                {x: 130, y: 140, w: 60, h: 20, type: 'normal'},
                {x: 240, y: 90, w: 80, h: 20, type: 'normal'}
            ],
            spikes: [
                {x: 80, y: 200, w: 20, h: 10, hidden: false}
            ]
        },
        3: {
            spawn: {x: 20, y: 170},
            goal: {x: 270, y: 170, w: 20, h: 20, moving: false, fake: true}, // Pintu palsu
            realGoal: {x: 30, y: 50, w: 20, h: 20}, // Pintu asli di tempat spawn
            platforms: [
                {x: 0, y: 200, w: 320, h: 40, type: 'normal'},
                {x: 20, y: 90, w: 50, h: 20, type: 'hidden', triggered: false} // Platform sembunyi
            ],
            spikes: []
        }
    };

    let currentData = null;

    function loadLevel(lvl) {
        if(!levelBlueprints[lvl]) lvl = 1;
        currentLevel = lvl;
        let bp = levelBlueprints[lvl];
        currentData = JSON.parse(JSON.stringify(bp));
        
        player.x = currentData.spawn.x;
        player.y = currentData.spawn.y;
        player.vx = 0;
        player.vy = 0;
        
        document.getElementById('lvlVal').textContent = currentLevel;
    }

    window.startGame = function() {
        document.getElementById('messageOverlay').style.display = 'none';
        if(gameState === 'gameover' || gameState === 'start') {
            if(gameState === 'gameover') {
                deaths++;
                document.getElementById('deathVal').textContent = deaths;
            }
            loadLevel(currentLevel); // Ulang level yang sama
        } else if(gameState === 'cleared') {
            let next = currentLevel + 1;
            if(next > 3) next = 1; // Balik ke level 1 kalau tamat
            loadLevel(next);
        }
        gameState = 'playing';
    }

    function triggerGameOver() {
        gameState = 'gameover';
        document.getElementById('overlayTitle').textContent = "WASTED";
        document.getElementById('overlayTitle').style.color = "#f38ba8";
        document.getElementById('overlayDesc').textContent = "Kamu kena jebakan! Jangan nyerah.";
        document.getElementById('overlayBtn').textContent = "Coba Lagi";
        document.getElementById('messageOverlay').style.display = 'flex';
    }

    function triggerClear() {
        gameState = 'cleared';
        document.getElementById('overlayTitle').textContent = "LEVEL CLEAR!";
        document.getElementById('overlayTitle').style.color = "#a6e3a1";
        document.getElementById('overlayDesc').textContent = "Berhasil selamat dari troll level " + currentLevel + "!";
        document.getElementById('overlayBtn').textContent = currentLevel < 3 ? "Lanjut Level" : "Tamat! Main Lagi";
        document.getElementById('messageOverlay').style.display = 'flex';
    }

    function update() {
        if(gameState !== 'playing') return;

        // Gerak Horizontal
        player.vx = 0;
        if(keys.left) player.vx = -player.speed;
        if(keys.right) player.vx = player.speed;

        player.x += player.vx;
        if(player.x < 0) player.x = 0;
        if(player.x + player.w > 320) player.x = 320 - player.w;

        // Gravitasi
        player.vy += 0.45;
        player.y += player.vy;
        player.grounded = false;

        // Fisika Platform
        currentData.platforms.forEach(p => {
            // Level 3 hidden platform
            if(p.type === 'hidden' && Math.abs(player.x - p.x) < 50) {
                p.triggered = true;
            }

            // Level 1 falling platform
            if(p.type === 'fall' && !p.triggered) {
                if(player.x + player.w > p.x && player.x < p.x + p.w && player.y + player.h >= p.y && player.y + player.h <= p.y + 12) {
                    p.triggered = true;
                }
            }
            if(p.triggered && p.type === 'fall') {
                p.y += 4; // Jatuh cepat
            }

            if((!p.triggered || p.y < 280) && (p.type !== 'hidden' || p.triggered)) {
                // Tabrakan lantai
                if(player.x + player.w > p.x && player.x < p.x + p.w && player.y + player.h >= p.y && player.y + player.h <= p.y + player.vy + 5 && player.vy >= 0) {
                    player.y = p.y - player.h;
                    player.vy = 0;
                    player.grounded = true;
                }
            }
        });

        // Lompat
        if(keys.jump && player.grounded) {
            player.vy = player.jumpPower;
            player.grounded = false;
        }

        // Duri Troll
        currentData.spikes.forEach(s => {
            if(s.hidden && Math.abs(player.x - s.x) < (s.triggerDist || 40)) {
                s.hidden = false;
            }
            if(!s.hidden) {
                if(player.x + player.w > s.x + 2 && player.x < s.x + s.w - 2 && player.y + player.h > s.y + 4 && player.y < s.y + s.h) {
                    triggerGameOver();
                }
            }
        });

        // Pintu Troll (Level 2 & 3)
        let g = currentData.goal;
        if(g.moving) {
            if(Math.abs(player.x - g.x) < 60) {
                g.x += 2.5; 
                if(g.x > 295) g.x = 295;
            }
        }
        if(g.fake && Math.abs(player.x - g.x) < 50) {
            g.y += 5; // Pintu jatuh ke jurang
            if(currentData.realGoal && currentData.realGoal.y < 80) {
                currentData.realGoal.y += 2; // Pintu asli turun
            }
        }

        // Jatuh ke bawah = mati
        if(player.y > 240) {
            triggerGameOver();
        }

        // Cek Menang
        if(player.x + player.w > g.x && player.x < g.x + g.w && player.y + player.h > g.y && player.y < g.y + g.h && !g.fake) {
            triggerClear();
        }
        if(currentData.realGoal) {
            let rg = currentData.realGoal;
            if(player.x + player.w > rg.x && player.x < rg.x + rg.w && player.y + player.h > rg.y && player.y < rg.y + rg.h) {
                triggerClear();
            }
        }
    }

    function draw() {
        ctx.fillStyle = '#11111b';
        ctx.fillRect(0, 0, 320, 240);

        // Render Platform
        currentData.platforms.forEach(p => {
            if((!p.triggered || p.y < 280)) {
                if(p.type === 'hidden' && !p.triggered) return; // Jangan gambar kalau masih sembunyi
                
                ctx.fillStyle = p.type === 'fall' ? '#f9e2af' : '#6c7086';
                ctx.fillRect(p.x, p.y, p.w, p.h);
                // Detail block
                ctx.fillStyle = 'rgba(255,255,255,0.1)';
                ctx.fillRect(p.x, p.y, p.w, 4);
            }
        });

        // Render Duri
        currentData.spikes.forEach(s => {
            if(!s.hidden) {
                ctx.fillStyle = '#f38ba8';
                ctx.beginPath();
                ctx.moveTo(s.x, s.y + s.h);
                ctx.lineTo(s.x + s.w / 2, s.y);
                ctx.lineTo(s.x + s.w, s.y + s.h);
                ctx.fill();
            }
        });

        // Render Pintu Goal
        let g = currentData.goal;
        ctx.fillStyle = g.fake && g.y > 220 ? 'transparent' : '#a6e3a1';
        if(!(g.fake && g.y > 220)) {
            ctx.fillRect(g.x, g.y, g.w, g.h);
            ctx.fillStyle = '#11111b';
            ctx.fillRect(g.x + 4, g.y + 4, g.w - 8, g.h - 8);
        }

        // Render Pintu Asli
        if(currentData.realGoal) {
            let rg = currentData.realGoal;
            ctx.fillStyle = '#a6e3a1';
            ctx.fillRect(rg.x, rg.y, rg.w, rg.h);
            ctx.fillStyle = '#11111b';
            ctx.fillRect(rg.x + 4, rg.y + 4, rg.w - 8, rg.h - 8);
        }

        // Render Player
        ctx.fillStyle = '#f38ba8'; // Warna merah darah
        ctx.fillRect(player.x, player.y, player.w, player.h);
        ctx.fillStyle = '#11111b'; // Mata
        ctx.fillRect(player.x + (player.vx >= 0 ? 8 : 2), player.y + 3, 4, 4);
    }

    function loop() {
        update();
        draw();
        requestAnimationFrame(loop);
    }

    // Input Handling
    const bindBtn = (id, downAction, upAction) => {
        const el = document.getElementById(id);
        if(!el) return;
        el.addEventListener('touchstart', (e) => { e.preventDefault(); downAction(); });
        el.addEventListener('touchend', (e) => { e.preventDefault(); upAction(); });
        el.addEventListener('mousedown', () => downAction());
        el.addEventListener('mouseup', () => upAction());
        el.addEventListener('mouseleave', () => upAction());
    };

    bindBtn('leftBtn', () => keys.left = true, () => keys.left = false);
    bindBtn('rightBtn', () => keys.right = true, () => keys.right = false);
    bindBtn('jumpBtn', () => keys.jump = true, () => keys.jump = false);

    // Initial render
    loadLevel(1);
    draw();
    loop();
})();
</script>
`;
}

async function handler(m, { sock, conn }) {
    const client = sock || conn;

    if (typeof m.react === 'function') await m.react('😈');

    try {
        const htmlPayload = renderHtmlLevelDevil();

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "jaka-leveldevil-game",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `Game Level Devil Dimulai!` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "jaka-leveldevil-game",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

    } catch (error) {
        console.error('Level Devil Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler };