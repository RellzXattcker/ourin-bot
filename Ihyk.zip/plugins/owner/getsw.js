const pluginConfig = {
    name: 'getsw',
    alias: ['colongsw', 'ambilsw', 'sw'],
    category: 'owner',
    description: 'Ambil/colong media dari status WhatsApp yang direply',
    usage: '.getsw (reply status)',
    example: '.getsw',
    isOwner: true, 
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    if (!m.quoted) {
        return m.reply(`⚠️ *Reply statusnya bos!*\n\n> Buka status WA, balas status tersebut lalu ketik \`${m.prefix}getsw\``)
    }

    m.react('🕖')

    try {
        const q = m.quoted
        // 1. Ambil objek raw message karena Baileys sering nyembunyiin tipe media di status
        const rawMsg = q.message || q.msg || q
        
        // 2. Deteksi paksa tipe pesannya (Mencari videoMessage / imageMessage terdalam)
        const mtype = q.mtype || q.type || (rawMsg ? Object.keys(rawMsg)[0] : '') || ''
        let mime = q.mimetype || rawMsg.mimetype || ''

        // 3. Validasi badak anti-lolos
        const isVideo = /video/.test(mime) || mtype === 'videoMessage' || !!rawMsg?.videoMessage
        const isImage = /image/.test(mime) || mtype === 'imageMessage' || !!rawMsg?.imageMessage
        const isAudio = /audio/.test(mime) || mtype === 'audioMessage' || !!rawMsg?.audioMessage

        // Set default mime buat video/image kalau dari raw objectnya kosong
        if (isVideo && !mime) mime = 'video/mp4'
        if (isImage && !mime) mime = 'image/jpeg'

        // Tangkap caption (Cek juga di dalam raw videoMessage nya)
        const originalCaption = q.text || q.caption || rawMsg?.caption || rawMsg?.videoMessage?.caption || rawMsg?.imageMessage?.caption || ''

        // Eksekusi jika beneran ada medianya
        if (isImage || isVideo || isAudio) {
            
            let mediaBuffer = null
            try {
                mediaBuffer = await q.download()
            } catch (err) {
                if (typeof sock.downloadMediaMessage === 'function') {
                    // Pakai raw message biar downloader Baileys nggak bingung
                    mediaBuffer = await sock.downloadMediaMessage(q)
                }
            }

            if (!mediaBuffer || mediaBuffer.length === 0) {
                throw new Error('Gagal menyedot media dari status. Video mungkin terlalu besar atau mesin gagal mendownload buffer.')
            }

            if (isImage) {
                await sock.sendMessage(m.chat, { 
                    image: mediaBuffer, 
                    caption: originalCaption 
                }, { quoted: m })
            } 
            else if (isVideo) {
                await sock.sendMessage(m.chat, { 
                    video: mediaBuffer, 
                    caption: originalCaption,
                    mimetype: mime 
                }, { quoted: m })
            } 
            else if (isAudio) {
                await sock.sendMessage(m.chat, { 
                    audio: mediaBuffer, 
                    mimetype: mime || 'audio/mp4', 
                    ptt: false 
                }, { quoted: m })
            }
        } 
        // Eksekusi jika hanya teks
        else {
            if (!originalCaption) {
                throw new Error('Tidak ada teks atau media yang terdeteksi! Pastikan yang lu reply beneran status, bukan notifikasi kosong.')
            }
            
            await sock.sendMessage(m.chat, { 
                text: `📝 *Teks Status:*\n\n${originalCaption}` 
            }, { quoted: m })
        }

        m.react('☑️')

    } catch (error) {
        console.error('[GetSW Plugin Error]', error)
        m.react('⚙️')
        m.reply(`❌ *GAGAL PROSES*\n\n> _${error.message}_`)
    }
}

export { pluginConfig as config, handler }