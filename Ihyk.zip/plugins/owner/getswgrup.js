const pluginConfig = {
    name: 'getswgrup',
    alias: ['copasw', 'colongswgrup', 'repostsw'],
    category: 'owner',
    description: 'Colong status WA lalu otomatis repost ke SW dengan tag Grup (Ultra Unwrap)',
    usage: '.getswgrup <id_grup/kosong jika di grup> (reply status)',
    example: '.getswgrup 120363000000000000@g.us',
    isOwner: true, 
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 3,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    // Pastikan user mereply pesan/status
    if (!m.quoted) {
        return m.reply(`⚠️ *Reply statusnya bos!*\n\n> Buka status WA target, balas status tersebut lalu ketik \`${m.prefix}getswgrup\``)
    }

    // 1. Tentukan ID Grup Target
    let groupId = ''
    if (m.args && m.args.length > 0) {
        groupId = m.args[0]
        if (!groupId.endsWith('@g.us')) groupId += '@g.us'
    } else if (m.isGroup) {
        // Kalau dipakai di dalam grup, otomatis ambil ID grup saat ini
        groupId = m.chat
    } else {
        return m.reply(`⚠️ *ID Grup tidak ditemukan!*\n\n> Karena lu pakai di Private Chat, lu wajib masukin ID Grupnya.\n> Contoh: \`${m.prefix}getswgrup 1234567890@g.us\``)
    }

    const groupNumber = groupId.split('@')[0]
    m.react('🕖')

    try {
        const q = m.quoted

        // 2. UNWRAP MESSAGE (Ngebongkar pesan WA yang dilapis/dibungkus)
        function unwrapMessage(msgObj) {
            if (!msgObj) return msgObj
            let msg = msgObj
            const wrappers = [
                'ephemeralMessage',
                'viewOnceMessage',
                'viewOnceMessageV2',
                'viewOnceMessageV2Extension',
                'documentWithCaptionMessage'
            ]
            let changed = true
            while (changed) {
                changed = false
                for (const w of wrappers) {
                    if (msg?.[w]?.message) {
                        msg = msg[w].message
                        changed = true
                    }
                }
            }
            return msg
        }

        const rawMessage = q.message ? unwrapMessage(q.message) : q
        
        // 3. DETEKTOR MEDIA AGRESIF
        const mime = q.mimetype || q.msg?.mimetype || rawMessage?.videoMessage?.mimetype || rawMessage?.imageMessage?.mimetype || rawMessage?.documentMessage?.mimetype || ''

        let isVideo = false
        let isImage = false
        let isAudio = false

        if (q.mtype === 'videoMessage' || q.videoMessage || q.msg?.videoMessage || rawMessage?.videoMessage || mime.includes('video')) {
            isVideo = true
        } else if (q.mtype === 'imageMessage' || q.imageMessage || q.msg?.imageMessage || rawMessage?.imageMessage || mime.includes('image')) {
            isImage = true
        } else if (q.mtype === 'audioMessage' || q.audioMessage || q.msg?.audioMessage || rawMessage?.audioMessage || mime.includes('audio')) {
            isAudio = true
        }

        // 4. Tangkap Caption dan Pasang Physical Tag (Mentions)
        let originalCaption = q.text || q.caption || q.msg?.caption || rawMessage?.videoMessage?.caption || rawMessage?.imageMessage?.caption || ''
        let textInput = originalCaption ? `${originalCaption}\n\n@${groupNumber}` : `@${groupNumber}`

        const viewers = [groupId, m.sender]
        const statusOptions = {
            statusJidList: viewers,
            backgroundColor: '#1E1E1E',
            font: 1
        }

        // 5. Eksekusi Download dan Repost
        if (isImage || isVideo || isAudio) {
            let mediaBuffer = null
            try {
                mediaBuffer = await q.download()
            } catch (err) {
                if (typeof sock.downloadMediaMessage === 'function') {
                    // Kasih object lengkap biar Baileys bisa nemu file aslinya
                    mediaBuffer = await sock.downloadMediaMessage({
                        key: q.key || m.quoted.key,
                        message: rawMessage || q.message
                    })
                }
            }

            if (!mediaBuffer || mediaBuffer.length === 0) {
                throw new Error('Gagal mendownload media dari status ini. File mungkin terlalu besar atau status sudah kadaluarsa.')
            }

            if (isImage) {
                await sock.sendMessage('status@broadcast', {
                    image: mediaBuffer,
                    caption: textInput,
                    mentions: [groupId]
                }, statusOptions)
            } else if (isVideo) {
                await sock.sendMessage('status@broadcast', {
                    video: mediaBuffer,
                    caption: textInput,
                    mentions: [groupId],
                    mimetype: mime || 'video/mp4' // Cegah bug video blank di WA
                }, statusOptions)
            } else if (isAudio) {
                await sock.sendMessage('status@broadcast', {
                    audio: mediaBuffer,
                    mimetype: mime || 'audio/mp4',
                    ptt: true,
                    mentions: [groupId]
                }, statusOptions)
            }
        } 
        // Jika yang dicopas cuma teks murni
        else {
            if (!originalCaption) {
                throw new Error('Tidak ada teks atau media yang terdeteksi. Pastikan lu me-reply statusnya dengan benar.')
            }
            await sock.sendMessage('status@broadcast', {
                text: textInput,
                mentions: [groupId]
            }, statusOptions)
        }

        await m.reply(`✅ *STATUS BERHASIL DI-COPAS & REPOST*\n\n> 🔗 Target Tag: *${groupId}*\n> _Cek status bot lu, media berhasil dicolong dan grupnya udah ditag._`)
        m.react('☑️')

    } catch (error) {
        console.error('[GetSW Grup Error]', error)
        m.react('⚙️')
        m.reply(`❌ *GAGAL PROSES*\n\n> _${error.message}_`)
    }
}

export { pluginConfig as config, handler }