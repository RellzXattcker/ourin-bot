// ===== spotifyplay-fixed.js =====
import axios from 'axios'
import { execFile } from 'node:child_process'
import { promisify } from 'node:util'
import { mkdtempSync, readFileSync, rmSync, writeFileSync, mkdirSync } from 'node:fs'
import { tmpdir } from 'node:os'
import { join } from 'node:path'
import crypto from 'node:crypto'
import ffmpegInstaller from '@ffmpeg-installer/ffmpeg'

const jalankan = promisify(execFile)
const BATAS_BASE64 = 800 * 1024 // Diperkecil jadi 800KB aman di WA
const BITRATE_MIN = { mp3: 24, opus: 12 }
const BITRATE_AWAL = { mp3: 48, opus: 32 }
const CODEC = {
  mp3: { args: (br) => ['-c:a', 'libmp3lame', '-b:a', `${br}k`, '-ac', '1', '-ar', '24000'], ext: 'mp3', mime: 'audio/mpeg' },
  opus: { args: (br) => ['-c:a', 'libopus', '-b:a', `${br}k`, '-ac', '1', '-ar', '24000'], ext: 'ogg', mime: 'audio/ogg' }
}

const API_LRCLIB = 'https://lrclib.net/api'
const UA = 'kurumi-bot/1.0 (+spotify lyrics)'
const DATA_DIR = join(process.cwd(), 'src', 'data', 'lyrics')
const TIMEOUT_MS = 8000
const TOLERANSI_DETIK = 4
const BATAS_LIRIK = 8 * 1024

// ===== CACHE SYSTEM =====
function berkasCache(kunci) {
  const hash = crypto.createHash('sha1').update(kunci).digest('hex')
  return join(DATA_DIR, `${hash}.json`)
}

function bacaCache(kunci) {
  try {
    return JSON.parse(readFileSync(berkasCache(kunci), 'utf8'))
  } catch {
    return null
  }
}

function tulisCache(kunci, isi) {
  try {
    mkdirSync(DATA_DIR, { recursive: true })
    writeFileSync(berkasCache(kunci), JSON.stringify(isi))
  } catch {}
}

// ===== LRC PARSER =====
function parseLrc(lrc) {
  const keluar = []
  for (const baris of String(lrc ?? '').split(/\r?\n/)) {
    const stempel = [...baris.matchAll(/\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g)]
    if (!stempel.length) continue
    const teks = baris.replace(/\[[^\]]*\]/g, '').trim()
    for (const [, mm, ss, pecahan] of stempel) {
      const ms = pecahan ? Number(pecahan.padEnd(3, '0')) : 0
      keluar.push({ time: (Number(mm) * 60000 + Number(ss) * 1000 + ms) / 1000, text: teks })
    }
  }
  return keluar.sort((a, b) => a.time - b.time)
}

// ===== FETCH HELPER =====
async function ambilJson(url) {
  const ac = new AbortController()
  const jam = setTimeout(() => ac.abort(), TIMEOUT_MS)
  try {
    const res = await fetch(url, { headers: { 'User-Agent': UA }, signal: ac.signal })
    if (res.status === 404 || !res.ok) return null
    return await res.json()
  } catch {
    return null
  } finally {
    clearTimeout(jam)
  }
}

// ===== LYRIC SEARCH =====
async function cariDekat(judul, artis, targetDetik) {
  const url = new URL(`${API_LRCLIB}/search`)
  url.searchParams.set('track_name', judul)
  if (artis) url.searchParams.set('artist_name', artis)
  const hasil = await ambilJson(url)
  if (!Array.isArray(hasil)) return null
  const bersinkron = hasil.filter((r) => r?.syncedLyrics)
  if (!bersinkron.length) return null
  bersinkron.sort((a, b) => Math.abs((a.duration ?? 0) - targetDetik) - Math.abs((b.duration ?? 0) - targetDetik))
  const terbaik = bersinkron[0]
  if (Math.abs((terbaik.duration ?? 0) - targetDetik) > TOLERANSI_DETIK) return null
  return terbaik
}

async function cariLirikSpotify(judul, artis, durasiMs) {
  const targetDetik = Math.floor(durasiMs / 1000)
  const kunci = `spotify|${judul}|${artis}|${targetDetik}`
  const tersimpan = bacaCache(kunci)
  if (tersimpan) return tersimpan.hasil

  let hit = null
  const urlGet = new URL(`${API_LRCLIB}/get`)
  urlGet.searchParams.set('artist_name', artis)
  urlGet.searchParams.set('track_name', judul)
  urlGet.searchParams.set('duration', String(targetDetik))

  const exact = await ambilJson(urlGet)
  if (exact?.syncedLyrics && !exact?.instrumental) hit = exact
  if (!hit) hit = await cariDekat(judul, artis, targetDetik)

  if (!hit?.syncedLyrics || hit?.instrumental) {
    tulisCache(kunci, { hasil: null })
    return null
  }

  const baris = parseLrc(hit.syncedLyrics)
  if (!baris.length) {
    tulisCache(kunci, { hasil: null })
    return null
  }

  const hasil = { baris, artis: hit.artistName || artis, judul: hit.trackName || judul }
  tulisCache(kunci, { hasil })
  return hasil
}

// ===== AUDIO COMPRESSION =====
async function kecilkan(masuk, keluar, codec, bitrate, maxDetik) {
  await jalankan(ffmpegInstaller.path, ['-y', '-i', masuk, '-vn', '-t', String(maxDetik), ...CODEC[codec].args(bitrate), keluar])
  return readFileSync(keluar)
}

async function audioDataUri(buffer, opsi = {}) {
  const { codec = 'opus', maxDetik = 480, batas = BATAS_BASE64 } = opsi
  if (!Buffer.isBuffer(buffer) || !buffer.length || !CODEC[codec]) return null

  const bitrate = opsi.bitrate ?? BITRATE_AWAL[codec]
  const minimum = BITRATE_MIN[codec]
  const dir = mkdtempSync(join(tmpdir(), 'kurumi-spotaudio-'))
  const masuk = join(dir, 'masuk')
  const keluar = join(dir, `keluar.${CODEC[codec].ext}`)

  try {
    writeFileSync(masuk, buffer)
    const batasBerkas = Math.floor((batas * 3) / 4)
    let br = bitrate
    let kecil = await kecilkan(masuk, keluar, codec, br, maxDetik)

    for (let putaran = 0; putaran < 4 && kecil.length > batasBerkas; putaran++) {
      const usul = Math.floor(((br * batasBerkas) / kecil.length) * 0.92)
      br = usul < minimum ? minimum : usul
      kecil = await kecilkan(masuk, keluar, codec, br, maxDetik)
    }

    if (kecil.length > batasBerkas) return null

    const b64 = kecil.toString('base64')
    return { dataUri: `data:${CODEC[codec].mime};base64,${b64}`, byte: b64.length, bitrate: br }
  } catch {
    return null
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
}

// ===== COVER COMPRESSION =====
async function coverDataUri(url, opsi = {}) {
  const { ukuran = 200, kualitas = 7, batas = 12 * 1024 } = opsi
  if (!url) return null

  const dir = mkdtempSync(join(tmpdir(), 'kurumi-spotcover-'))
  const masuk = join(dir, 'masuk')
  const keluar = join(dir, 'keluar.jpg')

  try {
    const res = await fetch(url, { signal: AbortSignal.timeout(10000) })
    if (!res.ok) return null

    writeFileSync(masuk, Buffer.from(await res.arrayBuffer()))
    await jalankan(ffmpegInstaller.path, ['-y', '-i', masuk, '-vf', `crop='min(iw,ih)':'min(iw,ih)',scale=${ukuran}:${ukuran}`, '-q:v', String(kualitas), keluar])

    const kecil = readFileSync(keluar)
    return { dataUri: `data:image/jpeg;base64,${kecil.toString('base64')}` }
  } catch {
    return null
  } finally {
    rmSync(dir, { recursive: true, force: true })
  }
}

// ===== SECURITY =====
function lolos(t) {
  return String(t ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;')
}

// ===== HTML PLAYER =====
function renderHtmlSpotifyPlayer({ judul = 'Unknown', artis = 'Spotify', audioSrc = '', coverSrc = '', lirik = [] }) {
  const nama = lolos(judul)
  const sub = lolos(artis)
  const hasLyrics = lirik.length > 0 ? 1 : 0
  const lyricsJson = JSON.stringify(lirik).replace(/<\//g, '<\\/')

  return `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>${nama}</title>
<style>
* { -webkit-tap-highlight-color: transparent; -webkit-user-select: none; user-select: none; box-sizing: border-box; }
body { margin: 0; padding: 0; background: #121212; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; color: #fff; }
.player-wrap { width: 100%; max-width: 420px; margin: 0 auto; padding: 16px; }
.player-card { background: linear-gradient(135deg, rgba(29, 185, 84, 0.2) 0%, rgba(18, 18, 18, 0.95) 100%); border-radius: 20px; overflow: hidden; padding: 16px; border: 1px solid rgba(255,255,255,0.08); box-shadow: 0 20px 60px rgba(0,0,0,0.8); }
.header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px; font-size: 11px; letter-spacing: 1px; color: #1db954; font-weight: 700; text-transform: uppercase; }
.cover { width: 100%; aspect-ratio: 1; border-radius: 12px; overflow: hidden; margin: 12px 0 16px; background: #282828; box-shadow: 0 12px 40px rgba(0,0,0,0.7); }
.cover img { width: 100%; height: 100%; object-fit: cover; }
.track { margin-bottom: 16px; }
.track-title { font-size: 20px; font-weight: 700; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.track-artist { font-size: 13px; color: #b3b3b3; margin-top: 4px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.lyrics { background: rgba(0,0,0,0.4); border-radius: 10px; padding: 12px; margin-bottom: 14px; min-height: 60px; border-left: 4px solid #1db954; display: flex; flex-direction: column; justify-content: center; gap: 6px; }
.lyric { font-size: 13px; color: rgba(255,255,255,0.3); white-space: nowrap; overflow: hidden; text-overflow: ellipsis; transition: all 0.2s; }
.lyric.active { color: #fff; font-weight: 700; font-size: 14px; }
.progress { margin: 12px 0; }
.progress-bar { background: #404040; height: 4px; border-radius: 2px; cursor: pointer; overflow: hidden; }
.progress-fill { background: #1db954; height: 100%; width: 0%; border-radius: 2px; }
.time-info { display: flex; justify-content: space-between; font-size: 11px; color: #b3b3b3; margin-top: 6px; }
.controls { display: flex; justify-content: center; align-items: center; gap: 12px; margin-top: 14px; }
.control-btn { background: none; border: none; color: #b3b3b3; cursor: pointer; padding: 8px; border-radius: 50%; transition: all 0.2s; }
.control-btn:hover { color: #1db954; transform: scale(1.1); }
.play-btn { width: 56px; height: 56px; background: #1db954; color: #000; border: none; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; font-size: 20px; font-weight: 700; transition: all 0.15s; }
.play-btn:active { transform: scale(0.95); }
.error-msg { background: rgba(255, 82, 82, 0.15); color: #ff5252; padding: 10px; border-radius: 8px; font-size: 12px; text-align: center; margin-top: 10px; display: none; border: 1px solid rgba(255, 82, 82, 0.3); }
</style>
</head>
<body>
<div class="player-wrap">
  <div class="player-card">
    <div class="header">
      <span>🎵 SPOTIFY</span>
      <span>NOW PLAYING</span>
    </div>
    <div class="cover"><img id="coverImg" src="${coverSrc || 'data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 300 300%22%3E%3Crect fill=%22%23282828%22 width=%22300%22 height=%22300%22/%3E%3Ctext x=%2250%25%22 y=%2250%25%22 font-size=%2224%22 fill=%22%231db954%22 text-anchor=%22middle%22 dy=%22.3em%22%3E🎵%3C/text%3E%3C/svg%3E' alt="Cover"></div>
    <div class="track">
      <div class="track-title">${nama}</div>
      <div class="track-artist">${sub}</div>
    </div>
    <div class="lyrics" id="lyrics" style="display: ${hasLyrics ? 'flex' : 'none'};"></div>
    <div class="progress">
      <div class="progress-bar" id="progressBar"><div class="progress-fill" id="progressFill"></div></div>
      <div class="time-info"><span id="curTime">0:00</span><span id="durTime">0:00</span></div>
    </div>
    <div class="controls">
      <button class="control-btn" id="prevBtn">⏮</button>
      <button class="play-btn" id="playBtn">▶</button>
      <button class="control-btn" id="nextBtn">⏭</button>
    </div>
    <div class="error-msg" id="errorMsg">⚠ Audio tidak dapat dimuat</div>
  </div>
</div>

<audio id="audio" preload="auto" src="${audioSrc}"></audio>

<script>
const audio = document.getElementById('audio');
const playBtn = document.getElementById('playBtn');
const progressBar = document.getElementById('progressBar');
const progressFill = document.getElementById('progressFill');
const curTime = document.getElementById('curTime');
const durTime = document.getElementById('durTime');
const lyrics = document.getElementById('lyrics');
const errorMsg = document.getElementById('errorMsg');
const coverImg = document.getElementById('coverImg');

const hasLyrics = ${hasLyrics} === 1;
const lyricsData = ${lyricsJson};
let activeLyricIdx = -1;

const fmt = (s) => {
  if (!Number.isFinite(s)) return '0:00';
  const m = Math.floor(s / 60);
  const sec = String(Math.floor(s % 60)).padStart(2, '0');
  return \`\${m}:\${sec}\`;
};

const renderLyrics = (idx) => {
  if (!hasLyrics || !lyricsData.length) return;
  lyrics.innerHTML = '';
  for (let i = Math.max(0, idx - 1); i <= Math.min(lyricsData.length - 1, idx + 1); i++) {
    const div = document.createElement('div');
    div.className = 'lyric' + (i === idx ? ' active' : '');
    div.textContent = lyricsData[i]?.text || '♪';
    lyrics.appendChild(div);
  }
};

renderLyrics(0);

audio.addEventListener('play', () => { playBtn.textContent = '⏸'; });
audio.addEventListener('pause', () => { playBtn.textContent = '▶'; });

audio.addEventListener('timeupdate', () => {
  if (audio.duration && Number.isFinite(audio.duration)) {
    const pct = (audio.currentTime / audio.duration) * 100;
    progressFill.style.width = pct + '%';
    curTime.textContent = fmt(audio.currentTime);
  }
  if (hasLyrics && lyricsData.length) {
    let idx = 0;
    for (let i = 0; i < lyricsData.length; i++) {
      if (audio.currentTime >= lyricsData[i].time) idx = i;
      else break;
    }
    if (idx !== activeLyricIdx) {
      renderLyrics(idx);
      activeLyricIdx = idx;
    }
  }
});

audio.addEventListener('loadedmetadata', () => {
  durTime.textContent = fmt(audio.duration);
});

audio.addEventListener('error', () => {
  errorMsg.style.display = 'block';
});

playBtn.addEventListener('click', () => {
  if (audio.paused) {
    const p = audio.play();
    if (p) p.catch(() => { errorMsg.style.display = 'block'; });
  } else {
    audio.pause();
  }
});

progressBar.addEventListener('click', (e) => {
  if (!audio.duration || !Number.isFinite(audio.duration)) return;
  const rect = progressBar.getBoundingClientRect();
  const pct = (e.clientX - rect.left) / rect.width;
  audio.currentTime = pct * audio.duration;
});

document.getElementById('prevBtn').addEventListener('click', () => { audio.currentTime = Math.max(0, audio.currentTime - 15); });
document.getElementById('nextBtn').addEventListener('click', () => { audio.currentTime = Math.min(audio.duration, audio.currentTime + 15); });
</script>
</body>
</html>`
}

// ===== PLUGIN CONFIG =====
const pluginConfig = {
  name: 'spotifyplay',
  alias: ['spotify', 'splay', 'play', 'spot'],
  category: 'music',
  description: 'Putar lagu Spotify + lirik real-time',
  usage: '.splay <link spotify>',
  example: '.splay https://open.spotify.com/track/5vQSU3pxA9atqN6zMrcTU7',
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 5,
  energi: 2,
  isEnabled: true
}

// ===== HANDLER =====
async function handler(m, { sock, conn, args }) {
  const client = sock || conn

  if (!args[0] || !args[0].match(/spotify\.(com|link)/i)) {
    return m.reply(`🎧 _Sertakan link Spotify_\n\n> Contoh: \`.splay https://open.spotify.com/track/xxx\``)
  }

  if (typeof m.react === 'function') await m.react('🔍')

  try {
    const query = args[0]
    const apiUrl = `https://api.nexaadev.my.id/api/spotify?url=${encodeURIComponent(query)}`
    const res = await axios.get(apiUrl, { timeout: 15000 })

    const data = res.data?.result || res.data?.data || res.data
    const rawAudioUrl = data?.url || data?.download || data?.audio || data?.link

    if (!rawAudioUrl) {
      if (typeof m.react === 'function') await m.react('❌')
      return m.reply('🥀 _API gagal mendapatkan link audio_')
    }

    if (typeof m.react === 'function') await m.react('⏳')

    const trackTitle = data?.title || 'Spotify Track'
    const trackArtist = data?.artist || data?.author || 'Unknown'
    const trackDurationMs = data?.durationMs || data?.duration || 180000
    const coverImage = data?.cover || data?.thumbnail || data?.image

    let lirikHasil = null
    try {
      lirikHasil = await cariLirikSpotify(trackTitle, trackArtist, trackDurationMs)
    } catch (e) {
      console.error('[spotifyplay] Lyrics error:', e)
    }

    const formatLirik = lirikHasil?.baris ? lirikHasil.baris.map(b => ({ time: b.time, text: b.text })) : []

    let audioSrc = rawAudioUrl // Fallback ke URL asli
    try {
      const audioRes = await axios.get(rawAudioUrl, { responseType: 'arraybuffer', timeout: 25000 })
      const encodedAudio = await audioDataUri(Buffer.from(audioRes.data), { codec: 'opus', maxDetik: 420 })
      if (encodedAudio?.dataUri) {
        audioSrc = encodedAudio.dataUri
      }
    } catch (e) {
      console.warn('[spotifyplay] Audio encode fallback to URL:', e.message)
    }

    let coverSrc = ''
    if (coverImage) {
      try {
        const coverRes = await coverDataUri(coverImage, { ukuran: 200, kualitas: 8 })
        if (coverRes?.dataUri) {
          coverSrc = coverRes.dataUri
        }
      } catch (e) {
        console.warn('[spotifyplay] Cover encode skip')
      }
    }

    const htmlPayload = renderHtmlSpotifyPlayer({
      judul: trackTitle,
      artis: trackArtist,
      audioSrc: audioSrc,
      coverSrc: coverSrc,
      lirik: formatLirik
    })

    await client.relayMessage(m.chat, {
      messageContextInfo: {
        deviceListMetadata: {},
        deviceListMetadataVersion: 2,
        botMetadata: {
          messageDisclaimerText: '',
          botResponseId: 'kurumi-spotify-player',
          verificationMetadata: {
            proofs: [{
              version: 1,
              useCase: 1,
              signature: 'TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==',
              certificateChain: [
                'TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg',
                'TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=='
              ]
            }]
          }
        },
        botForwardedMessage: {
          message: {
            richResponseMessage: {
              messageType: 1,
              submessages: [{ messageType: 2, messageText: `${trackTitle} - ${trackArtist}` }],
              unifiedResponse: {
                data: Buffer.from(JSON.stringify({
                  response_id: 'kurumi-spotify-player',
                  sections: [{
                    view_model: {
                      primitive: {
                        __typename: 'GenAIaeacdsnwHtmlPrimitive',
                        payload: htmlPayload,
                        trusted_sources: ['hirara.dev', new URL(audioSrc).hostname].filter(Boolean)
                      },
                      __typename: 'GenAISingleLayoutViewModel'
                    }
                  }]
                })).toString('base64')
              },
              contextInfo: {
                forwardingScore: 1,
                isForwarded: true,
                forwardOrigin: 4
              }
            }
          }
        }
      }
    }, {})

    if (typeof m.react === 'function') await m.react('🎵')

  } catch (error) {
    console.error('[spotifyplay]', error)
    if (typeof m.react === 'function') await m.react('❌')
    await m.reply(`❌ *ERROR*\n\n> ${error.message?.slice(0, 80)}`)
  }
}

export { pluginConfig as config, handler }