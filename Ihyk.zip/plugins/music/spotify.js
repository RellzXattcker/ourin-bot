import axios from 'axios';
import yts from 'yt-search';
import ytdl from '@distube/ytdl-core';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { mkdtempSync, readFileSync, rmSync, writeFileSync, mkdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import crypto from 'node:crypto';
import ffmpegInstaller from '@ffmpeg-installer/ffmpeg';

// ================= KONFIGURASI PLUGIN =================
const pluginConfig = {
    name: 'spotify',
    alias: ['spotify', 'splay', 'play', 'spot'],
    category: 'music',
    description: 'Putar lagu Spotify (Preview/Full) beserta lirik dengan Player Card UI',
    usage: '.splay <judul lagu>',
    example: '.splay die with a smile',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 3,
    isEnabled: true
};

const jalankan = promisify(execFile);
const BATAS_BASE64 = 900 * 1024;
const BITRATE_MIN = { mp3: 24, opus: 12 };
const BITRATE_AWAL = { mp3: 64, opus: 48 };
const CODEC = {
    mp3: { args: (br) => [ '-c:a', 'libmp3lame', '-b:a', `${br}k`, '-ac', '1', '-ar', br < 32 ? '24000' : '32000' ], ext: 'mp3', mime: 'audio/mpeg' },
    opus: { args: (br) => ['-c:a', 'libopus', '-b:a', `${br}k`, '-ac', '1', '-ar', '24000'], ext: 'ogg', mime: 'audio/ogg' }
};

const API_LRCLIB = 'https://lrclib.net/api';
const SPOTIFY_TOKEN_URL = 'https://open.spotify.com/get_access_token?reason=transport&productType=embed';
const SPOTIFY_API = 'https://api.spotify.com/v1';
const UA = 'ackles-bot/1.0 (+play spotify)';
const DATA_DIR = join(process.cwd(), 'src', 'data', 'lyrics');
const TIMEOUT_MS = 8000;
const TOLERANSI_DETIK = 6;
const BATAS_LIRIK = 8 * 1024;

// ================= CACHE LIRIK =================
function berkasCache(kunci) {
    const hash = crypto.createHash('sha1').update(kunci).digest('hex');
    return join(DATA_DIR, `${hash}.json`);
}
function bacaCache(kunci) {
    try { return JSON.parse(readFileSync(berkasCache(kunci), 'utf8')); } catch { return null; }
}
function tulisCache(kunci, isi) {
    try {
        mkdirSync(DATA_DIR, { recursive: true });
        writeFileSync(berkasCache(kunci), JSON.stringify(isi));
    } catch {}
}

function parseLrc(lrc) {
    const keluar = [];
    for (const baris of String(lrc ?? '').split(/\r?\n/)) {
        const stempel = [...baris.matchAll(/\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g)];
        if (!stempel.length) continue;
        const teks = baris.replace(/\[[^\]]*\]/g, '').trim();
        for (const [, mm, ss, pecahan] of stempel) {
            const ms = pecahan ? Number(pecahan.padEnd(3, '0')) : 0;
            keluar.push({ time: (Number(mm) * 60000 + Number(ss) * 1000 + ms) / 1000, text: teks });
        }
    }
    return keluar.sort((a, b) => a.time - b.time);
}

async function ambilJson(url) {
    const ac = new AbortController();
    const jam = setTimeout(() => ac.abort(), TIMEOUT_MS);
    try {
        const res = await fetch(url, { headers: { 'User-Agent': UA }, signal: ac.signal });
        if (res.status === 404 || !res.ok) return null;
        return await res.json();
    } catch { return null; } finally { clearTimeout(jam); }
}

async function cariDekat(judul, artis, targetDetik) {
    const url = new URL(`${API_LRCLIB}/search`);
    url.searchParams.set('track_name', judul);
    if (artis) url.searchParams.set('artist_name', artis);
    const hasil = await ambilJson(url);
    if (!Array.isArray(hasil)) return null;
    const bersinkron = hasil.filter((r) => r?.syncedLyrics);
    if (!bersinkron.length) return null;
    bersinkron.sort((a, b) => Math.abs((a.duration ?? 0) - targetDetik) - Math.abs((b.duration ?? 0) - targetDetik));
    const terbaik = bersinkron[0];
    if (Math.abs((terbaik.duration ?? 0) - targetDetik) > TOLERANSI_DETIK) return null;
    return terbaik;
}

async function cariLirik({ judul, artis, durasiDetik }) {
    const targetDetik = Number(durasiDetik) || 0;
    if (!judul || !targetDetik) return null;
    const kunci = `spotify|${judul}|${artis}|${targetDetik}`;
    const tersimpan = bacaCache(kunci);
    if (tersimpan) return tersimpan.hasil;
    let hit = null;
    let sumber = '';
    const urlGet = new URL(`${API_LRCLIB}/get`);
    urlGet.searchParams.set('artist_name', artis || '');
    urlGet.searchParams.set('track_name', judul);
    urlGet.searchParams.set('duration', String(targetDetik));
    const exact = await ambilJson(urlGet);
    if (exact?.syncedLyrics && !exact?.instrumental) { hit = exact; sumber = 'get'; }
    if (!hit) { const r = await cariDekat(judul, artis, targetDetik); if (r) { hit = r; sumber = 'search'; } }
    if (!hit) { const r = await cariDekat(judul, '', targetDetik); if (r) { hit = r; sumber = 'search-judul'; } }
    if (!hit?.syncedLyrics || hit?.instrumental) { tulisCache(kunci, { hasil: null }); return null; }
    const baris = parseLrc(hit.syncedLyrics);
    if (!baris.length) { tulisCache(kunci, { hasil: null }); return null; }
    const hasil = { baris, artis: hit.artistName ?? artis, judul: hit.trackName ?? judul, durasi: hit.duration ?? 0, selisih: Math.round(Math.abs((hit.duration ?? 0) - targetDetik)), sumber };
    while (JSON.stringify(hasil.baris).length > BATAS_LIRIK) {
        hasil.baris = hasil.baris.slice(0, Math.floor(hasil.baris.length * 0.8));
        if (hasil.baris.length < 4) { tulisCache(kunci, { hasil: null }); return null; }
    }
    tulisCache(kunci, { hasil });
    return hasil;
}

// ================= PENCARIAN SPOTIFY =================
let tokenCache = { nilai: null, exp: 0 };

async function ambilTokenSpotify() {
    if (tokenCache.nilai && Date.now() < tokenCache.exp - 10000) return tokenCache.nilai;
    const res = await axios.get(SPOTIFY_TOKEN_URL, { headers: { 'User-Agent': UA }, timeout: TIMEOUT_MS });
    const data = res.data;
    if (!data?.accessToken) throw new Error('Gagal ambil token Spotify');
    tokenCache = { nilai: data.accessToken, exp: data.accessTokenExpirationTimestampMs ?? Date.now() + 55 * 60000 };
    return tokenCache.nilai;
}

async function cariSpotify(query, limit = 1) {
    const token = await ambilTokenSpotify();
    const res = await axios.get(`${SPOTIFY_API}/search`, {
        params: { q: query, type: 'track', limit },
        headers: { Authorization: `Bearer ${token}` },
        timeout: TIMEOUT_MS
    }).catch(() => null);
    const track = res?.data?.tracks?.items?.[0];
    if (!track) return null;
    return {
        id: track.id,
        judul: track.name,
        artis: track.artists.map((a) => a.name).join(', '),
        album: track.album?.name ?? '',
        cover: track.album?.images?.[0]?.url ?? '',
        durasiDetik: Math.round((track.duration_ms ?? 0) / 1000),
        preview: track.preview_url ?? null,
        url: track.external_urls?.spotify ?? '',
        eksplisit: !!track.explicit
    };
}

// ================= FALLBACK AUDIO PENUH VIA YOUTUBE =================
async function cariVideoCocok(judul, artis, durasiDetik) {
    const hasil = await yts(`${artis} - ${judul} audio`).catch(() => null);
    const daftar = hasil?.videos ?? [];
    if (!daftar.length) return null;
    daftar.sort((a, b) => Math.abs((a.seconds ?? 0) - durasiDetik) - Math.abs((b.seconds ?? 0) - durasiDetik));
    const terbaik = daftar[0];
    if (Math.abs((terbaik.seconds ?? 0) - durasiDetik) > 12) return null;
    return terbaik;
}

async function unduhAudioYoutube(videoUrl) {
    const potongan = [];
    const stream = ytdl(videoUrl, { filter: 'audioonly', quality: 'highestaudio' });
    for await (const chunk of stream) potongan.push(chunk);
    return Buffer.concat(potongan);
}

async function unduhPreviewSpotify(previewUrl) {
    const res = await axios.get(previewUrl, { responseType: 'arraybuffer', timeout: TIMEOUT_MS }).catch(() => null);
    if (!res?.data) return null;
    return Buffer.from(res.data);
}

// ================= KOMPRESI AUDIO & COVER =================
async function kecilkan(masuk, keluar, codec, bitrate, maxDetik) {
    await jalankan(ffmpegInstaller.path, ['-y', '-i', masuk, '-vn', '-t', String(maxDetik), ...CODEC[codec].args(bitrate), keluar]);
    return readFileSync(keluar);
}

async function audioDataUri(buffer, opsi = {}) {
    const { codec = 'opus', maxDetik = 600, batas = BATAS_BASE64 } = opsi;
    if (!Buffer.isBuffer(buffer) || !buffer.length || !CODEC[codec]) return null;
    const bitrate = opsi.bitrate ?? BITRATE_AWAL[codec];
    const minimum = BITRATE_MIN[codec];
    const dir = mkdtempSync(join(tmpdir(), 'ackles-spotify-audio-'));
    const masuk = join(dir, 'masuk');
    const keluar = join(dir, `keluar.${CODEC[codec].ext}`);
    try {
        writeFileSync(masuk, buffer);
        const batasBerkas = Math.floor((batas * 3) / 4);
        let br = bitrate;
        let kecil = await kecilkan(masuk, keluar, codec, br, maxDetik);
        for (let putaran = 0; putaran < 3 && kecil.length > batasBerkas; putaran++) {
            const usul = Math.floor(((br * batasBerkas) / kecil.length) * 0.94);
            br = usul < minimum ? minimum : usul;
            kecil = await kecilkan(masuk, keluar, codec, br, maxDetik);
        }
        if (kecil.length > batasBerkas) return null;
        const b64 = kecil.toString('base64');
        return { dataUri: `data:${CODEC[codec].mime};base64,${b64}`, byte: b64.length, bitrate: br, codec };
    } catch { return null; } finally { rmSync(dir, { recursive: true, force: true }); }
}

async function coverDataUri(url, opsi = {}) {
    const { ukuran = 240, kualitas = 6, batas = 14 * 1024 } = opsi;
    if (!url || !/^https?:\/\//.test(url)) return null;
    const dir = mkdtempSync(join(tmpdir(), 'ackles-spotify-cover-'));
    const masuk = join(dir, 'masuk');
    const keluar = join(dir, 'keluar.jpg');
    try {
        const res = await fetch(url, { signal: AbortSignal.timeout(12000) });
        if (!res.ok) return null;
        const buf = Buffer.from(await res.arrayBuffer());
        if (buf.length < 512) return null;
        writeFileSync(masuk, buf);
        let q = kualitas;
        let kecil = null;
        for (; q <= 9; q++) {
            await jalankan(ffmpegInstaller.path, ['-y', '-i', masuk, '-vf', `crop='min(iw,ih)':'min(iw,ih)',scale=${ukuran}:${ukuran}`, '-q:v', String(q), keluar]);
            kecil = readFileSync(keluar);
            if ((kecil.length * 4) / 3 <= batas) break;
        }
        if (!kecil || (kecil.length * 4) / 3 > batas) return null;
        const b64 = kecil.toString('base64');
        return { dataUri: `data:image/jpeg;base64,${b64}`, byte: b64.length, kualitas: q };
    } catch { return null; } finally { rmSync(dir, { recursive: true, force: true }); }
}

function lolos(t) {
    return String(t ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

// ================= RENDER HTML PLAYER =================
function renderHtmlSpotifyPlayer({ judul = 'Unknown', artis = 'Spotify', audioSrc = '', coverSrc = '', caption = 'Spotify Audio Player', lirik = [], modePreview = false }) {
    const nama = lolos(judul);
    const sub = lolos(artis);
    const hasLyrics = lirik.length > 0 ? 1 : 0;
    const lyricsJson = JSON.stringify(lirik).replace(/<\//g, '<\\/');
    const badge = modePreview ? '<div class="previewBadge">PRATINJAU 30 DETIK</div>' : '';

    return `
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
* { -webkit-tap-highlight-color: transparent; -webkit-user-select: none; user-select: none; box-sizing: border-box; }
body { margin: 0; background: transparent; font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #f2fdf5; }
.player-wrap { width: 100%; max-width: 400px; margin: auto; padding: 12px; }
.player-card {
  background: linear-gradient(180deg, rgba(30,60,40,0.55) 0%, rgba(10,16,12,0.97) 55%);
  border-radius: 18px; overflow: hidden; box-shadow: 0 10px 34px rgba(0,0,0,0.6);
  padding: 14px 18px 18px; transition: background 0.4s ease;
}
.player-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
.chevron { color: #bde; font-size: 16px; opacity: 0.7; }
.source-info { text-align: center; flex: 1; }
.source-label { font-size: 9px; letter-spacing: 2px; color: #b9f2c8; font-weight: 700; text-transform: uppercase; }
.source-channel { font-size: 12px; color: #fff; font-weight: 600; margin-top: 1px; }
.kebab { color: #bde; font-size: 16px; opacity: 0.7; }
.cover-box { width: 100%; aspect-ratio: 1; border-radius: 12px; overflow: hidden; margin: 10px 0 14px; background: #000; position: relative; }
.cover-box img { width: 100%; height: 100%; object-fit: cover; }
.previewBadge { position: absolute; top: 8px; right: 8px; background: rgba(29,185,84,0.92); color: #052912; font-size: 9px; font-weight: 800; letter-spacing: 0.5px; padding: 3px 7px; border-radius: 6px; }
.track-row { display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px; gap: 10px; }
.track-title { font-size: 16px; font-weight: 700; color: #fff; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; max-width: 280px; }
.track-artist { font-size: 12px; color: #bcd9c4; margin-top: 2px; }
.heartBtn { background: none; border: none; color: #bcd9c4; cursor: pointer; font-size: 20px; flex-shrink: 0; transition: color 0.2s, transform 0.2s; }
.heartBtn.active { color: #1DB954; transform: scale(1.15); }
.lyricsPreview { min-height: 54px; margin-bottom: 10px; display: flex; flex-direction: column; justify-content: center; gap: 3px; }
.lyricLine { font-size: 12.5px; color: rgba(210,235,215,0.45); text-align: left; transition: color 0.25s; }
.lyricLine.active { color: #f2fdf5; font-weight: 600; }
.lyricsEmpty { font-size: 12px; color: rgba(210,235,215,0.4); font-style: italic; }
.audioError { font-size: 11.5px; color: #ff8a80; text-align: center; margin: 8px 0 0; display: none; }
.progressArea { margin: 6px 0 4px; }
.progressTrack { background: rgba(255,255,255,0.2); height: 3px; border-radius: 2px; cursor: pointer; position: relative; }
.progressBar { background: #1DB954; height: 100%; border-radius: 2px; width: 0%; position: relative; pointer-events: none; }
.progressBar::after { content: ''; position: absolute; right: -5px; top: 50%; transform: translateY(-50%); width: 10px; height: 10px; border-radius: 50%; background: #fff; }
.timeRow { display: flex; justify-content: space-between; font-size: 10.5px; color: #bcd9c4; margin-top: 6px; }
.controls { display: flex; justify-content: space-between; align-items: center; margin-top: 14px; padding: 0 2px; }
.ctrlBtn { background: none; border: none; color: #f2fdf5; cursor: pointer; font-size: 15px; padding: 6px; display: flex; align-items: center; justify-content: center; position: relative; transition: color 0.2s; }
.ctrlBtn.active { color: #1DB954; }
.playBtn { background: #1DB954; color: #052912; border: none; border-radius: 50%; width: 50px; height: 50px; display: flex; justify-content: center; align-items: center; cursor: pointer; font-size: 17px; }
.seekLabel { position: absolute; bottom: -2px; font-size: 7px; font-weight: 700; }
.captionText { text-align: center; font-size: 11px; color: rgba(210,235,215,0.55); margin-top: 12px; font-style: italic; }
</style>
<div class="player-wrap">
  <div class="player-card" id="playerCard">
    <div class="player-header">
      <span class="chevron">⌄</span>
      <div class="source-info">
        <div class="source-label">SPOTIFY</div>
        <div class="source-channel">${sub}</div>
      </div>
      <span class="kebab">⋮</span>
    </div>
    <div class="cover-box"><img id="coverImg" src="${coverSrc}" alt="Cover">${badge}</div>
    <div class="track-row">
      <div>
        <div class="track-title">${nama}</div>
        <div class="track-artist">${sub}</div>
      </div>
      <button class="heartBtn" id="heartBtn"><svg id="heartIcon" viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="2"><path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.6l-1-1a5.5 5.5 0 0 0-7.8 7.8l1 1L12 21l7.8-7.6 1-1a5.5 5.5 0 0 0 0-7.8z"/></svg></button>
    </div>
    <div class="lyricsPreview" id="lyricsPreview">
      <div class="lyricsEmpty">Lirik tidak tersedia</div>
    </div>
    <div class="progressArea">
      <div class="progressTrack" id="progressTrack"><div class="progressBar" id="progressBar"></div></div>
      <div class="timeRow"><span id="curTime">0:00</span><span id="durTime">0:00</span></div>
    </div>
    <div class="controls">
      <button class="ctrlBtn" id="noteBtn"><svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/></svg></button>
      <button class="ctrlBtn" id="rewindBtn"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 2.13-9.36L1 10"/></svg><span class="seekLabel">10</span></button>
      <button class="playBtn" id="playBtn"><svg id="playIcon" viewBox="0 0 24 24" width="17" height="17" fill="currentColor"><polygon points="6 3 21 12 6 21 6 3"/></svg></button>
      <button class="ctrlBtn" id="forwardBtn"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.13-9.36L23 10"/></svg><span class="seekLabel">10</span></button>
      <button class="ctrlBtn" id="repeatBtn"><svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="17 1 21 5 17 9"/><path d="M3 11V9a4 4 0 0 1 4-4h14"/><polyline points="7 23 3 19 7 15"/><path d="M21 13v2a4 4 0 0 1-4 4H3"/></svg></button>
    </div>
    <div class="captionText">${lolos(caption)}</div>
    <div class="audioError" id="audioError">⚠ Audio gagal dimuat — link mungkin invalid/expired</div>
  </div>
</div>
<audio id="audioEl" preload="auto" src="${audioSrc}"></audio>
<script>
(function(){
    const audio = document.getElementById('audioEl');
    const playBtn = document.getElementById('playBtn');
    const progressBar = document.getElementById('progressBar');
    const progressTrack = document.getElementById('progressTrack');
    const curTime = document.getElementById('curTime');
    const durTime = document.getElementById('durTime');
    const heartBtn = document.getElementById('heartBtn');
    const repeatBtn = document.getElementById('repeatBtn');
    const noteBtn = document.getElementById('noteBtn');
    const rewindBtn = document.getElementById('rewindBtn');
    const forwardBtn = document.getElementById('forwardBtn');
    const lyricsPreview = document.getElementById('lyricsPreview');

    const hasLyrics = ${hasLyrics} === 1;
    const lyrics = ${lyricsJson};

    function fmt(s){
        if(!Number.isFinite(s)) return '0:00';
        return Math.floor(s/60) + ':' + String(Math.floor(s%60)).padStart(2,'0');
    }

    function renderLyricsWindow(idx) {
        lyricsPreview.innerHTML = '';
        if (!hasLyrics || !lyrics.length) return;
        const window = [idx - 1, idx, idx + 1];
        window.forEach(i => {
            const div = document.createElement('div');
            div.className = 'lyricLine' + (i === idx ? ' active' : '');
            div.textContent = (lyrics[i] && lyrics[i].text) ? lyrics[i].text : '';
            lyricsPreview.appendChild(div);
        });
    }
    renderLyricsWindow(0);

    let activeLyricIndex = -1;
    function updateLyrics(t) {
        if (!hasLyrics || !lyrics.length) return;
        let idx = 0;
        for (let i = 0; i < lyrics.length; i++) {
            if (t >= lyrics[i].time) idx = i; else break;
        }
        if (idx !== activeLyricIndex) {
            renderLyricsWindow(idx);
            activeLyricIndex = idx;
        }
    }

    audio.addEventListener('timeupdate', () => {
        if(audio.duration){
            progressBar.style.width = (audio.currentTime / audio.duration) * 100 + '%';
            curTime.textContent = fmt(audio.currentTime);
        }
        updateLyrics(audio.currentTime);
    });
    audio.addEventListener('loadedmetadata', () => { durTime.textContent = fmt(audio.duration); });
    audio.addEventListener('error', () => {
        const box = document.getElementById('audioError');
        if (box) box.style.display = 'block';
    });

    function safe(fn) {
        return function(e) {
            try { fn(e); } catch (err) {}
        };
    }

    playBtn.addEventListener('click', safe(() => {
        const icon = document.getElementById('playIcon');
        if(audio.paused){
            const p = audio.play();
            if (p && typeof p.catch === 'function') p.catch(() => {});
            icon.innerHTML = '<rect x="5" y="4" width="5" height="16"/><rect x="14" y="4" width="5" height="16"/>';
        } else {
            audio.pause();
            icon.innerHTML = '<polygon points="6 3 21 12 6 21 6 3"/>';
        }
    }));

    progressTrack.addEventListener('click', safe((e) => {
        if (!audio.duration || !Number.isFinite(audio.duration)) return;
        const rect = progressTrack.getBoundingClientRect();
        const ratio = (e.clientX - rect.left) / rect.width;
        audio.currentTime = ratio * audio.duration;
    }));

    rewindBtn.addEventListener('click', safe(() => { audio.currentTime = Math.max(0, (audio.currentTime || 0) - 10); }));
    forwardBtn.addEventListener('click', safe(() => { if (audio.duration) audio.currentTime = Math.min(audio.duration, (audio.currentTime || 0) + 10); }));

    let mengulang = false;
    repeatBtn.addEventListener('click', safe(() => { mengulang = !mengulang; audio.loop = mengulang; repeatBtn.classList.toggle('active', mengulang); }));

    let disukai = false;
    heartBtn.addEventListener('click', safe(() => { disukai = !disukai; heartBtn.classList.toggle('active', disukai); }));
})();
</script>
`;
}

// ================= ORKESTRASI =================
async function prosesSpotify(query) {
    const track = await cariSpotify(query);
    if (!track) return null;

    let bufferAudio = null;
    let modePreview = false;
    let caption = 'Spotify Audio Player';

    if (track.preview) {
        bufferAudio = await unduhPreviewSpotify(track.preview);
        modePreview = true;
        caption = `${track.judul} - ${track.artis} • Pratinjau resmi Spotify (30 detik)`;
    }
    if (!bufferAudio) {
        const video = await cariVideoCocok(track.judul, track.artis, track.durasiDetik);
        if (video?.url) {
            bufferAudio = await unduhAudioYoutube(video.url).catch(() => null);
            modePreview = false;
            caption = `${track.judul} - ${track.artis} • Audio penuh via YouTube (fallback)`;
        }
    }
    if (!bufferAudio) return { track, gagal: 'audio-tidak-ditemukan' };

    const [audio, cover, lirik] = await Promise.all([
        audioDataUri(bufferAudio, { codec: 'opus', maxDetik: modePreview ? 35 : 600 }),
        coverDataUri(track.cover),
        cariLirik({ judul: track.judul, artis: track.artis, durasiDetik: track.durasiDetik })
    ]);
    if (!audio) return { track, gagal: 'kompresi-audio-gagal' };

    const html = renderHtmlSpotifyPlayer({
        judul: track.judul,
        artis: track.artis,
        audioSrc: audio.dataUri,
        coverSrc: cover?.dataUri ?? '',
        caption,
        lirik: lirik?.baris ?? [],
        modePreview
    });

    return { track, html, modePreview };
}

// ================= HANDLER UTAMA BOT =================
async function handler(m, { sock, conn, args }) {
    const client = sock || conn;

    if (!args[0]) {
        return m.reply(`🎧 _"Lagu apa yang ingin Master putar dari Spotify?"_\n\n> ⟡ *Contoh:* \`.splay die with a smile\``);
    }

    if (typeof m.react === 'function') await m.react('⏳');

    try {
        const query = args.join(' ');
        const hasil = await prosesSpotify(query);

        if (!hasil) {
            if (typeof m.react === 'function') await m.react('❌');
            return m.reply('🥀 _Lagu tidak ditemukan di Spotify._');
        }

        if (hasil.gagal) {
            if (typeof m.react === 'function') await m.react('❌');
            return m.reply(`🥀 _Gagal memproses lagu: ${hasil.gagal}_`);
        }

        const htmlPayload = hasil.html;
        const trackTitle = hasil.track.judul;
        const trackArtist = hasil.track.artis;

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "kurumi-spotify-player",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `${trackTitle} - ${trackArtist}` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "kurumi-spotify-player",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

        if (typeof m.react === 'function') await m.react('🎵');

    } catch (error) {
        console.error('Spotify Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler, cariSpotify, cariLirik, audioDataUri, coverDataUri, renderHtmlSpotifyPlayer, prosesSpotify };