const pluginConfig = {
    name: 'applemusic',
    alias: ['applemusic', 'appleplay', 'playapple'],
    category: 'downloader',
    description: 'Cari dan putar preview musik dari Apple Music langsung di chat',
    usage: '.applemusic <judul lagu>',
    example: '.applemusic Shape of You',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 5,
    isEnabled: true
};

function renderHtmlAppleMusic(track) {
    return `
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<style>
* { box-sizing: border-box; -webkit-tap-highlight-color: transparent; user-select: none; font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; }
body { margin: 0; background: transparent; color: #fff; overflow: hidden; }
.player-wrap { width: 100%; max-width: 360px; margin: auto; padding: 10px; }
.player-card {
  background: #1c1c1e;
  border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(0,0,0,0.8);
  padding: 16px; border: 1px solid rgba(255,255,255,0.1);
}
.brand { text-align: center; font-size: 10px; letter-spacing: 3px; color: #fa243c; text-transform: uppercase; margin-bottom: 12px; font-weight: 700; }
.artwork-wrap { width: 130px; height: 130px; border-radius: 14px; margin: 0 auto 14px; overflow: hidden; box-shadow: 0 6px 20px rgba(0,0,0,0.5); background: #2c2c2e; }
.artwork-wrap img { width: 100%; height: 100%; object-fit: cover; display: block; }
.song-title { font-size: 15px; font-weight: 700; text-align: center; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; padding: 0 8px; color: #fff; }
.song-artist { text-align: center; font-size: 12px; color: #fa243c; margin-top: 3px; font-weight: 500; }
.prog-wrap { margin: 16px 0 8px; }
.prog-track { width: 100%; height: 4px; background: rgba(255,255,255,0.15); border-radius: 2px; cursor: pointer; position: relative; }
.prog-fill { height: 100%; background: #fa243c; border-radius: 2px; width: 0%; position: relative; }
.time-row { display: flex; justify-content: space-between; margin-top: 6px; font-size: 10px; color: rgba(255,255,255,0.4); }
.controls { display: flex; justify-content: center; align-items: center; gap: 20px; margin-top: 10px; }
.play-btn { width: 50px; height: 50px; border-radius: 50%; background: #fa243c; border: none; color: #fff; cursor: pointer; display: flex; align-items: center; justify-content: center; box-shadow: 0 4px 15px rgba(250,36,60,0.4); transition: transform 0.2s; }
.play-btn:active { transform: scale(0.92); }
.footer-info { text-align: center; font-size: 10px; color: rgba(255,255,255,0.3); margin-top: 12px; }
</style>
<div class="player-wrap">
  <div class="player-card">
    <div class="brand">Apple Music Preview</div>
    <div class="artwork-wrap">
      <img src="${track.artwork}" alt="Cover">
    </div>
    <div class="song-title">${track.title}</div>
    <div class="song-artist">${track.artist}</div>
    
    <div class="prog-wrap">
      <div class="prog-track" id="trackBar">
        <div class="prog-fill" id="fillBar"></div>
      </div>
      <div class="time-row">
        <span id="curTime">0:00</span>
        <span id="durTime">0:30</span>
      </div>
    </div>

    <div class="controls">
      <button class="play-btn" id="playBtn" onclick="togglePlay()">
        <svg id="pico" width="20" height="20" viewBox="0 0 24 24" fill="white">
          <polygon points="5 3 19 12 5 21 5 3"></polygon>
        </svg>
      </button>
    </div>
    <div class="footer-info">Apple Music 30s Audio Preview</div>
  </div>
</div>
<audio id="audioEl" src="${track.previewUrl}"></audio>
<script>
const aud = document.getElementById('audioEl');
const fillBar = document.getElementById('fillBar');
const curTime = document.getElementById('curTime');
const playBtn = document.getElementById('playBtn');
const pico = document.getElementById('pico');

let isPlaying = false;

function togglePlay() {
    if(isPlaying) {
        aud.pause();
        isPlaying = false;
        pico.innerHTML = '<polygon points="5 3 19 12 5 21 5 3"></polygon>';
    } else {
        aud.play();
        isPlaying = true;
        pico.innerHTML = '<rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect>';
    }
}

aud.addEventListener('timeupdate', () => {
    let pct = (aud.currentTime / aud.duration) * 100;
    fillBar.style.width = pct + '%';
    curTime.textContent = fmt(aud.currentTime);
});

aud.addEventListener('ended', () => {
    isPlaying = false;
    pico.innerHTML = '<polygon points="5 3 19 12 5 21 5 3"></polygon>';
    fillBar.style.width = '0%';
    curTime.textContent = '0:00';
});

document.getElementById('trackBar').addEventListener('click', (e) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const pos = (e.clientX - rect.left) / rect.width;
    aud.currentTime = pos * aud.duration;
});

function fmt(s) {
    let m = Math.floor(s/60);
    let sec = Math.floor(s%60);
    return m + ':' + (sec < 10 ? '0' : '') + sec;
}
</script>
`;
}

async function handler(m, { sock, conn, text }) {
    const client = sock || conn;

    if (!text) {
        if (typeof m.reply === 'function') return m.reply('❌ Masukkan judul lagu yang ingin dicari!\n\nContoh: *.applemusic Shape of You*');
        return;
    }

    if (typeof m.react === 'function') await m.react('🎵');

    try {
        // Menggunakan public iTunes Search API (Apple Music API)
        const searchUrl = `https://itunes.apple.com/search?term=${encodeURIComponent(text)}&entity=song&limit=1`;
        const response = await fetch(searchUrl);
        const json = await response.json();

        if (!json.results || json.results.length === 0) {
            if (typeof m.react === 'function') await m.react('❌');
            return m.reply('❌ Lagu tidak ditemukan di Apple Music.');
        }

        const song = json.results[0];
        const trackData = {
            title: song.trackName,
            artist: song.artistName,
            artwork: song.artworkUrl100.replace('100x100bb.jpg', '600x600bb.jpg'), // Resolusi cover lebih besar
            previewUrl: song.previewUrl // URL audio preview 30 detik resmi dari Apple
        };

        const htmlPayload = renderHtmlAppleMusic(trackData);

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "jaka-applemusic-player",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `Memutar: ${song.trackName} - ${song.artistName}` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "jaka-applemusic-player",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

    } catch (error) {
        console.error('Apple Music Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        if (typeof m.reply === 'function') await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler };