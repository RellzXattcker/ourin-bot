import axios from "axios";
import FormData from "form-data";
import te from "../../src/lib/ourin-error.js";

const pluginConfig = {
  name: "uhd",
  alias: ["upscale", "hd"],
  category: "canvas",
  description: "Upscale gambar menjadi UHD",
  usage: ".uhd (reply gambar)",
  example: ".uhd",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  energi: 2,
  isEnabled: true,
};

async function uploadUguu(buffer) {
  const form = new FormData();

  form.append("files[]", buffer, {
    filename: "image.jpg",
  });

  const { data } = await axios.post(
    "https://uguu.se/upload.php",
    form,
    {
      headers: form.getHeaders(),
      timeout: 60000,
    }
  );

  if (!data?.files?.[0]?.url) {
    throw new Error("Upload Uguu gagal");
  }

  return data.files[0].url;
}

async function handler(m, { sock }) {
  const quoted = m.quoted ? m.quoted : m;

  let media;

  try {
    media = await quoted.download();
  } catch {
    return m.reply("🖼️ Reply atau kirim gambar terlebih dahulu.");
  }

  if (!media || !Buffer.isBuffer(media)) {
    return m.reply("🖼️ Reply atau kirim gambar terlebih dahulu.");
  }

  await m.react("🕕");

  try {
    const imageUrl = await uploadUguu(media);

    const apiUrl =
      `https://kyzznekoo.zone.id/api/upscale/v5/uhd?url=` +
      encodeURIComponent(imageUrl);

    const res = await axios.get(apiUrl, {
      responseType: "arraybuffer",
      timeout: 120000,
    });

    if (
      res.headers["content-type"] &&
      !res.headers["content-type"].includes("image")
    ) {
      throw new Error("Response bukan gambar");
    }

    await sock.sendMessage(
      m.chat,
      {
        image: Buffer.from(res.data),
        caption: "✨ UHD Upscale"
      },
      {
        quoted: m
      }
    );

    await m.react("✅");

  } catch (error) {
    console.error("[UHD]", error);

    await m.react("❌");

    m.reply(
      te(
        m.prefix,
        m.command,
        m.pushName
      )
    );
  }
}

export { pluginConfig as config, handler };