const pluginConfig = {
    name: 'fakeff',
    alias: ['fffake', 'fakefreefire', 'ff'],
    category: 'canvas',
    description: 'Buat fake akun Free Fire dengan nickname custom',
    usage: '.fakeff <nickname>',
    example: '.fakeff IdkBot',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 2,
    isEnabled: true
}

async function handler(m, { sock, args }) {
    try {
        // Check if nickname is provided
        if (!args[0]) {
            return m.reply('❌ *MASUKKAN NICKNAME*\n\nContoh: .fakeff IdkBot');
        }

        // Get nickname from arguments
        const nickname = args.join(' ');
        
        // Send processing message
        await m.reply('⏳ *MEMBUAT FAKE FF...*\n\n> Mohon tunggu sebentar...');

        // API URL with nickname
        const apiUrl = `https://api.nexadev.my.id/maker/fakeff?nickname=${encodeURIComponent(nickname)}`;

        // Fetch image from API
        const response = await fetch(apiUrl);
        
        if (!response.ok) {
            throw new Error(`API Error: ${response.status}`);
        }

        // Get image buffer
        const imageBuffer = await response.arrayBuffer();
        const buffer = Buffer.from(imageBuffer);

        // Send the image
        await sock.sendMessage(
            m.chat,
            {
                image: buffer,
                caption: `✅ *FAKE FF BERHASIL DIBUAT*\n\n📛 *Nickname:* ${nickname}\n📱 *Platform:* Free Fire\n🔰 *Status:* Fake Account\n\n> _Powered by JAKA_`
            },
            { quoted: m }
        );

    } catch (error) {
        console.error('FakeFF Plugin Error:', error);
        
        // Error handling with more details
        let errorMessage = '❌ *GAGAL MEMBUAT FAKE FF*\n\n';
        
        if (error.message.includes('fetch')) {
            errorMessage += '> ⚠️ Gagal terhubung ke server. Coba lagi nanti.';
        } else if (error.message.includes('404')) {
            errorMessage += '> ⚠️ API tidak ditemukan. Periksa kembali URL.';
        } else {
            errorMessage += `> ${error.message}`;
        }
        
        await m.reply(errorMessage);
    }
}

export { pluginConfig as config, handler };