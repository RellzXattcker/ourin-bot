import axios from "axios";
import config from "../../config.js";
import { uploadTo0x0 } from "../../src/lib/ourin-tmpfiles.js";
import te from "../../src/lib/ourin-error.js";

const pluginConfig = {
  name: "fakeffduo",
  alias: ["fakefreefirduo"],
  category: "canvas",
  description: "Membuat gambar ff duo",
  usage: ".fakeffduo <nama1|nama2>",
  example: ".fakeffduo Jack|Jaka",
  isOwner: false,
  isPremium: false,
  isGroup: false,
  isPrivate: false,
  cooldown: 10,
  energi: 1,
  isEnabled: true,
};

async function handler(m, { sock }) {
  const cleanText = m.text?.replace(new RegExp(`^\\${m.prefix}${m.command}\\s*`, 'i'), '').trim();

  if (!cleanText || !cleanText.includes("|")) {
    return m.reply(
      `*FAKE FF DUO*\n\n> Contoh: \`${m.prefix}${m.command} nama1|nama2\``
    );
  }

  const nama = cleanText.split("|").map(v => v.trim());
  if (nama.length < 2 || !nama[0] || !nama[1]) {
    return m.reply(
      `❌ Format salah!\n> Contoh: \`${m.prefix}${m.command} nama1|nama2\``
    );
  }

  await m.react("🕕");

  try {
    // 1. Membuat URL API baru dengan metode GET dan parameter yang dinamis (URL di-encode agar aman jika ada spasi)
    const apiUrl = `https://apii.nexadev.my.id/fakeffduo?nickname1=${encodeURIComponent(nama[0])}&nickname2=${encodeURIComponent(nama[1])}`;

    // 2. Fetch API menggunakan axios dengan responseType arraybuffer
    const response = await axios.get(apiUrl, { responseType: 'arraybuffer' });
    const contentType = response.headers['content-type'];
    
    let imagePayload;

    // 3. Pengecekan: Apakah API mengembalikan JSON atau langsung Buffer Gambar
    if (contentType && contentType.includes('application/json')) {
      const jsonResult = JSON.parse(response.data.toString('utf-8'));
      if (!jsonResult.url) {
        throw new Error(jsonResult.message || "Gagal mendapatkan gambar dari API.");
      }
      imagePayload = { url: jsonResult.url };
    } else {
      // Jika response langsung berupa gambar (buffer)
      imagePayload = Buffer.from(response.data, "binary");
    }

    // 4. Mengirimkan gambar via Baileys
    await sock.sendMessage(
      m.chat, 
      { 
        image: imagePayload, 
        caption: 'Nih🗿'
      }, 
      { quoted: m }
    );

    await m.react("✅");
  } catch (error) {
    console.error("[FakeFFDuo Error]:", error);
    await m.react("☢");
    await m.reply(`❌ *Gagal memuat gambar:* ${error.response?.data?.message || error.message}`);
  }
}

export { pluginConfig as config, handler };