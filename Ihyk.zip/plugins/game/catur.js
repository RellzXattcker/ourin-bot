import axios from 'axios';

// Konfigurasi dasar plugin
const pluginConfig = {
    name: 'chessai',
    alias: ['catur', 'playcatur'],
    category: 'games',
    description: 'Main catur interaktif ngelawan AI langsung di chat',
    usage: '.catur',
    example: '.catur',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 10,
    energi: 5,
    isEnabled: true
};

function lolos(t) {
    return String(t ?? '').replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}

function renderHtmlCatur({ judul = 'Catur', pemain = 'Kamu', level = 2 } = {}) {
    const nama = lolos(judul);
    const sub = lolos(pemain);
    const kedalaman = Math.max(1, Math.min(3, Number(level) || 2));

    return `
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
* { -webkit-tap-highlight-color: transparent; -webkit-user-select: none; user-select: none; box-sizing: border-box; }
body { margin: 0; background: transparent; font-family: 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #f2e9e4; }
.player-wrap { width: 100%; max-width: 400px; margin: auto; padding: 12px; position: relative; }
.player-card {
  background: linear-gradient(180deg, rgba(60,40,30,0.55) 0%, rgba(18,14,12,0.97) 55%);
  border-radius: 18px; overflow: hidden; box-shadow: 0 10px 34px rgba(0,0,0,0.6);
  padding: 14px 18px 18px;
}
.player-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; }
.chevron { color: #cbb; font-size: 16px; opacity: 0.7; }
.source-info { text-align: center; flex: 1; }
.source-label { font-size: 9px; letter-spacing: 2px; color: #d8c3b5; font-weight: 700; text-transform: uppercase; }
.source-channel { font-size: 12px; color: #fff; font-weight: 600; margin-top: 1px; }
.kebab { color: #cbb; font-size: 16px; opacity: 0.7; cursor: pointer; }
.statusBar { text-align: center; font-size: 12.5px; color: #f0dcc8; font-weight: 600; margin-bottom: 10px; min-height: 16px; }
.statusBar.skak { color: #ff7a68; }
.statusBar.menang { color: #7ee08a; }
.statusBar.kalah { color: #ff7a68; }
.board-wrap { display: grid; grid-template-columns: repeat(8, 1fr); grid-template-rows: repeat(8, 1fr); width: 100%; aspect-ratio: 1; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 18px rgba(0,0,0,0.5); }
.sq { position: relative; display: flex; align-items: center; justify-content: center; font-size: 6.6vw; max-font-size: 26px; cursor: pointer; }
.sq.light { background: #ead9c4; }
.sq.dark { background: #6c4a37; }
.sq.light.last { background: #f2e08a; }
.sq.dark.last { background: #b8933f; }
.sq.check { background: #b5342a !important; }
.sq.sel::before { content: ''; position: absolute; inset: 3px; border: 3px solid #ffcf6b; border-radius: 4px; pointer-events: none; }
.sq .dot { width: 24%; height: 24%; border-radius: 50%; background: rgba(20,14,10,0.4); }
.sq .ring { position: absolute; inset: 8%; border: 3.5px solid rgba(180,40,30,0.6); border-radius: 50%; }
.piece { line-height: 1; filter: drop-shadow(0 1px 1px rgba(0,0,0,0.55)); }
.piece.w { color: #fdf8f0; }
.piece.b { color: #1b1310; }
.coordRow { display: flex; justify-content: space-between; font-size: 9px; color: rgba(230,215,205,0.4); margin-top: 4px; padding: 0 2px; }
.controls { display: flex; justify-content: center; gap: 10px; margin-top: 14px; }
.ctrlBtn2 { background: rgba(255,255,255,0.08); border: none; color: #f2e9e4; font-size: 11.5px; font-weight: 600; padding: 9px 14px; border-radius: 20px; cursor: pointer; }
.ctrlBtn2:active { background: rgba(255,255,255,0.18); }
.captionText { text-align: center; font-size: 11px; color: rgba(230,215,205,0.55); margin-top: 12px; font-style: italic; }
.promoOverlay { position: absolute; inset: 0; background: rgba(10,7,6,0.88); border-radius: 18px; display: none; align-items: center; justify-content: center; flex-direction: column; gap: 12px; z-index: 5; }
.promoOverlay .lbl { font-size: 13px; color: #f0dcc8; font-weight: 600; }
.promoRow { display: flex; gap: 10px; }
.promoBtn { background: #f2e9e4; border: none; width: 50px; height: 50px; border-radius: 12px; font-size: 26px; cursor: pointer; display: flex; align-items: center; justify-content: center; }
</style>
<div class="player-wrap">
  <div class="player-card" id="caturCard" style="position:relative;">
    <div class="player-header">
      <span class="chevron">⌄</span>
      <div class="source-info">
        <div class="source-label">CATUR • VS KOMPUTER</div>
        <div class="source-channel">${sub}</div>
      </div>
      <span class="kebab" id="flipBtn">⟲</span>
    </div>
    <div class="statusBar" id="statusBar">Giliran kamu (Putih)</div>
    <div class="board-wrap" id="boardWrap"></div>
    <div class="coordRow" id="coordRow"></div>
    <div class="controls">
      <button class="ctrlBtn2" id="resetBtn">Main Ulang</button>
      <button class="ctrlBtn2" id="undoBtn">Undo</button>
    </div>
    <div class="captionText" id="captionText">${nama} • Level ${kedalaman}</div>
    <div class="promoOverlay" id="promoOverlay">
      <div class="lbl">Promosi pion jadi:</div>
      <div class="promoRow" id="promoRow"></div>
    </div>
  </div>
</div>
<script>
(function(){
    var KEDALAMAN = ${kedalaman};
    var NILAI = { p: 100, n: 320, b: 330, r: 500, q: 900, k: 20000 };
    var GLIF = {
        w: { k: '\\u2654', q: '\\u2655', r: '\\u2656', b: '\\u2657', n: '\\u2658', p: '\\u2659' },
        b: { k: '\\u265A', q: '\\u265B', r: '\\u265C', b: '\\u265D', n: '\\u265E', p: '\\u265F' }
    };
    var FILES = ['a','b','c','d','e','f','g','h'];

    function papanAwal(){
        var urutan = ['r','n','b','q','k','b','n','r'];
        var b = [];
        b.push(urutan.map(function(t){ return { t: t, c: 'b' }; }));
        b.push([0,1,2,3,4,5,6,7].map(function(){ return { t: 'p', c: 'b' }; }));
        for (var i = 0; i < 4; i++) b.push([null,null,null,null,null,null,null,null]);
        b.push([0,1,2,3,4,5,6,7].map(function(){ return { t: 'p', c: 'w' }; }));
        b.push(urutan.map(function(t){ return { t: t, c: 'w' }; }));
        return b;
    }

    function state0(){
        return {
            board: papanAwal(),
            giliran: 'w',
            enPassant: null,
            castling: { wK: true, wQ: true, bK: true, bQ: true },
            status: 'main',
            langkahTerakhir: null
        };
    }

    var state = state0();
    var flipped = false;
    var dipilih = null;
    var legalDariPilihan = [];
    var riwayat = [];
    var promoTunda = null;
    var kunci = false;

    function kloneState(s){
        return {
            board: s.board.map(function(row){ return row.map(function(p){ return p ? { t: p.t, c: p.c } : null; }); }),
            giliran: s.giliran,
            enPassant: s.enPassant ? { r: s.enPassant.r, c: s.enPassant.c } : null,
            castling: { wK: s.castling.wK, wQ: s.castling.wQ, bK: s.castling.bK, bQ: s.castling.bQ },
            status: s.status,
            langkahTerakhir: s.langkahTerakhir ? { dari: s.langkahTerakhir.dari, ke: s.langkahTerakhir.ke } : null
        };
    }

    function diPapan(r, c){ return r >= 0 && r < 8 && c >= 0 && c < 8; }
    function lawan(w){ return w === 'w' ? 'b' : 'w'; }

    function cariRaja(board, warna){
        for (var r = 0; r < 8; r++) for (var c = 0; c < 8; c++) {
            var p = board[r][c];
            if (p && p.t === 'k' && p.c === warna) return { r: r, c: c };
        }
        return null;
    }

    var ARAH_KUDA = [[-2,-1],[-2,1],[-1,-2],[-1,2],[1,-2],[1,2],[2,-1],[2,1]];
    var ARAH_DIAG = [[-1,-1],[-1,1],[1,-1],[1,1]];
    var ARAH_LURUS = [[-1,0],[1,0],[0,-1],[0,1]];

    function kotakDiserang(board, r, c, olehWarna){
        var dp = olehWarna === 'w' ? 1 : -1;
        if (diPapan(r + dp, c - 1)) { var p1 = board[r + dp][c - 1]; if (p1 && p1.t === 'p' && p1.c === olehWarna) return true; }
        if (diPapan(r + dp, c + 1)) { var p2 = board[r + dp][c + 1]; if (p2 && p2.t === 'p' && p2.c === olehWarna) return true; }
        for (var i = 0; i < ARAH_KUDA.length; i++) {
            var nr = r + ARAH_KUDA[i][0], nc = c + ARAH_KUDA[i][1];
            if (diPapan(nr, nc)) { var pk = board[nr][nc]; if (pk && pk.t === 'n' && pk.c === olehWarna) return true; }
        }
        for (var j = 0; j < ARAH_DIAG.length; j++) {
            var dr = ARAH_DIAG[j][0], dc = ARAH_DIAG[j][1], nr2 = r + dr, nc2 = c + dc;
            while (diPapan(nr2, nc2)) {
                var pp = board[nr2][nc2];
                if (pp) { if (pp.c === olehWarna && (pp.t === 'b' || pp.t === 'q')) return true; break; }
                nr2 += dr; nc2 += dc;
            }
        }
        for (var k = 0; k < ARAH_LURUS.length; k++) {
            var dr2 = ARAH_LURUS[k][0], dc2 = ARAH_LURUS[k][1], nr3 = r + dr2, nc3 = c + dc2;
            while (diPapan(nr3, nc3)) {
                var pp2 = board[nr3][nc3];
                if (pp2) { if (pp2.c === olehWarna && (pp2.t === 'r' || pp2.t === 'q')) return true; break; }
                nr3 += dr2; nc3 += dc2;
            }
        }
        for (var x = -1; x <= 1; x++) for (var y = -1; y <= 1; y++) {
            if (x === 0 && y === 0) continue;
            var nr4 = r + x, nc4 = c + y;
            if (diPapan(nr4, nc4)) { var pr = board[nr4][nc4]; if (pr && pr.t === 'k' && pr.c === olehWarna) return true; }
        }
        return false;
    }

    function rajaDiskak(s, warna){
        var pos = cariRaja(s.board, warna);
        if (!pos) return false;
        return kotakDiserang(s.board, pos.r, pos.c, lawan(warna));
    }

    function langkahPseudo(s, r, c){
        var b = s.board, p = b[r][c];
        if (!p) return [];
        var hasil = [];
        function tambah(nr, nc, opsi){
            opsi = opsi || {};
            hasil.push({ dari: { r: r, c: c }, ke: { r: nr, c: nc }, promosi: !!opsi.promosi, enPassant: !!opsi.enPassant, castling: opsi.castling || null });
        }
        if (p.t === 'p') {
            var dir = p.c === 'w' ? -1 : 1;
            var awal = p.c === 'w' ? 6 : 1;
            var akhir = p.c === 'w' ? 0 : 7;
            if (diPapan(r + dir, c) && !b[r + dir][c]) {
                tambah(r + dir, c, { promosi: (r + dir === akhir) });
                if (r === awal && !b[r + 2 * dir][c]) tambah(r + 2 * dir, c, {});
            }
            [c - 1, c + 1].forEach(function(nc){
                if (!diPapan(r + dir, nc)) return;
                var target = b[r + dir][nc];
                if (target && target.c !== p.c) tambah(r + dir, nc, { promosi: (r + dir === akhir) });
                else if (!target && s.enPassant && s.enPassant.r === r + dir && s.enPassant.c === nc) tambah(r + dir, nc, { enPassant: true });
            });
        } else if (p.t === 'n') {
            ARAH_KUDA.forEach(function(d){
                var nr = r + d[0], nc = c + d[1];
                if (diPapan(nr, nc) && (!b[nr][nc] || b[nr][nc].c !== p.c)) tambah(nr, nc, {});
            });
        } else if (p.t === 'b' || p.t === 'r' || p.t === 'q') {
            var arah = p.t === 'b' ? ARAH_DIAG : p.t === 'r' ? ARAH_LURUS : ARAH_DIAG.concat(ARAH_LURUS);
            arah.forEach(function(d){
                var nr = r + d[0], nc = c + d[1];
                while (diPapan(nr, nc)) {
                    var t = b[nr][nc];
                    if (!t) { tambah(nr, nc, {}); }
                    else { if (t.c !== p.c) tambah(nr, nc, {}); break; }
                    nr += d[0]; nc += d[1];
                }
            });
        } else if (p.t === 'k') {
            for (var x = -1; x <= 1; x++) for (var y = -1; y <= 1; y++) {
                if (x === 0 && y === 0) continue;
                var nr2 = r + x, nc2 = c + y;
                if (diPapan(nr2, nc2) && (!b[nr2][nc2] || b[nr2][nc2].c !== p.c)) tambah(nr2, nc2, {});
            }
            var baris = p.c === 'w' ? 7 : 0;
            if (r === baris && c === 4 && !rajaDiskak(s, p.c)) {
                var hakK = p.c === 'w' ? s.castling.wK : s.castling.bK;
                var hakQ = p.c === 'w' ? s.castling.wQ : s.castling.bQ;
                if (hakK && !b[baris][5] && !b[baris][6] && b[baris][7] && b[baris][7].t === 'r' &&
                    !kotakDiserang(b, baris, 5, lawan(p.c)) && !kotakDiserang(b, baris, 6, lawan(p.c))) {
                    tambah(baris, 6, { castling: 'K' });
                }
                if (hakQ && !b[baris][1] && !b[baris][2] && !b[baris][3] && b[baris][0] && b[baris][0].t === 'r' &&
                    !kotakDiserang(b, baris, 2, lawan(p.c)) && !kotakDiserang(b, baris, 3, lawan(p.c))) {
                    tambah(baris, 2, { castling: 'Q' });
                }
            }
        }
        return hasil;
    }

    function terapkan(s, mv, promoPilihan){
        var ns = kloneState(s);
        var b = ns.board;
        var p = b[mv.dari.r][mv.dari.c];
        var warna = p.c;
        ns.enPassant = null;
        if (mv.enPassant) b[mv.dari.r][mv.ke.c] = null;
        if (mv.castling) {
            var baris = mv.dari.r;
            if (mv.castling === 'K') { b[baris][5] = b[baris][7]; b[baris][7] = null; }
            else { b[baris][3] = b[baris][0]; b[baris][0] = null; }
        }
        if (p.t === 'p' && Math.abs(mv.ke.r - mv.dari.r) === 2) ns.enPassant = { r: (mv.ke.r + mv.dari.r) / 2, c: mv.dari.c };
        b[mv.ke.r][mv.ke.c] = { t: mv.promosi ? (promoPilihan || 'q') : p.t, c: warna };
        b[mv.dari.r][mv.dari.c] = null;
        if (p.t === 'k') { if (warna === 'w') { ns.castling.wK = false; ns.castling.wQ = false; } else { ns.castling.bK = false; ns.castling.bQ = false; } }
        if (p.t === 'r') {
            if (warna === 'w' && mv.dari.r === 7 && mv.dari.c === 0) ns.castling.wQ = false;
            if (warna === 'w' && mv.dari.r === 7 && mv.dari.c === 7) ns.castling.wK = false;
            if (warna === 'b' && mv.dari.r === 0 && mv.dari.c === 0) ns.castling.bQ = false;
            if (warna === 'b' && mv.dari.r === 0 && mv.dari.c === 7) ns.castling.bK = false;
        }
        if (mv.ke.r === 0 && mv.ke.c === 0) ns.castling.bQ = false;
        if (mv.ke.r === 0 && mv.ke.c === 7) ns.castling.bK = false;
        if (mv.ke.r === 7 && mv.ke.c === 0) ns.castling.wQ = false;
        if (mv.ke.r === 7 && mv.ke.c === 7) ns.castling.wK = false;
        ns.giliran = lawan(warna);
        ns.langkahTerakhir = { dari: mv.dari, ke: mv.ke };
        return ns;
    }

    function langkahLegalKotak(s, r, c){
        var p = s.board[r][c];
        if (!p) return [];
        var pseudo = langkahPseudo(s, r, c);
        var legal = [];
        for (var i = 0; i < pseudo.length; i++) {
            var mv = pseudo[i];
            var hasil = terapkan(s, mv, 'q');
            if (!rajaDiskak(hasil, p.c)) legal.push(mv);
        }
        return legal;
    }

    function semuaLangkahLegal(s, warna){
        var semua = [];
        for (var r = 0; r < 8; r++) for (var c = 0; c < 8; c++) {
            var p = s.board[r][c];
            if (p && p.c === warna) semua = semua.concat(langkahLegalKotak(s, r, c));
        }
        return semua;
    }

    function evaluasi(s){
        var skor = 0;
        for (var r = 0; r < 8; r++) for (var c = 0; c < 8; c++) {
            var p = s.board[r][c];
            if (p) skor += (p.c === 'w' ? NILAI[p.t] : -NILAI[p.t]);
        }
        return skor;
    }

    function minimax(s, depth, alpha, beta, maksimal){
        var giliranWarna = maksimal ? 'w' : 'b';
        var moves = semuaLangkahLegal(s, giliranWarna);
        if (moves.length === 0) {
            if (rajaDiskak(s, giliranWarna)) return maksimal ? -99000 - depth : 99000 + depth;
            return 0;
        }
        if (depth === 0) return evaluasi(s);
        moves.sort(function(a, b2){
            var ca = s.board[a.ke.r][a.ke.c] ? 1 : 0;
            var cb = s.board[b2.ke.r][b2.ke.c] ? 1 : 0;
            return cb - ca;
        });
        if (maksimal) {
            var best = -Infinity;
            for (var i = 0; i < moves.length; i++) {
                var ns = terapkan(s, moves[i], 'q');
                var val = minimax(ns, depth - 1, alpha, beta, false);
                if (val > best) best = val;
                if (best > alpha) alpha = best;
                if (beta <= alpha) break;
            }
            return best;
        } else {
            var worst = Infinity;
            for (var j = 0; j < moves.length; j++) {
                var ns2 = terapkan(s, moves[j], 'q');
                var val2 = minimax(ns2, depth - 1, alpha, beta, true);
                if (val2 < worst) worst = val2;
                if (worst < beta) beta = worst;
                if (beta <= alpha) break;
            }
            return worst;
        }
    }

    function langkahAI(){
        var moves = semuaLangkahLegal(state, 'b');
        if (!moves.length) return null;
        var terbaik = [];
        var skorTerbaik = Infinity;
        for (var i = 0; i < moves.length; i++) {
            var ns = terapkan(state, moves[i], 'q');
            var skor = minimax(ns, Math.max(0, KEDALAMAN - 1), -Infinity, Infinity, true);
            if (skor < skorTerbaik - 15) { skorTerbaik = skor; terbaik = [moves[i]]; }
            else if (skor <= skorTerbaik + 15) { terbaik.push(moves[i]); }
        }
        return terbaik[Math.floor(Math.random() * terbaik.length)];
    }

    var boardWrap = document.getElementById('boardWrap');
    var statusBar = document.getElementById('statusBar');
    var coordRow = document.getElementById('coordRow');
    var promoOverlay = document.getElementById('promoOverlay');
    var promoRow = document.getElementById('promoRow');
    var captionText = document.getElementById('captionText');

    function labelKotak(r, c){ return FILES[c] + (8 - r); }

    function gambar(){
        boardWrap.innerHTML = '';
        var tujuan = {};
        legalDariPilihan.forEach(function(m){ tujuan[m.ke.r + '_' + m.ke.c] = m; });
        var posRajaSkak = null;
        if (rajaDiskak(state, state.giliran)) posRajaSkak = cariRaja(state.board, state.giliran);
        for (var vr = 0; vr < 8; vr++) {
            for (var vc = 0; vc < 8; vc++) {
                var r = flipped ? 7 - vr : vr;
                var c = flipped ? 7 - vc : vc;
                var el = document.createElement('div');
                var terang = (r + c) % 2 === 0;
                el.className = 'sq ' + (terang ? 'light' : 'dark');
                if (state.langkahTerakhir && ((state.langkahTerakhir.dari.r === r && state.langkahTerakhir.dari.c === c) || (state.langkahTerakhir.ke.r === r && state.langkahTerakhir.ke.c === c))) el.className += ' last';
                if (posRajaSkak && posRajaSkak.r === r && posRajaSkak.c === c) el.className += ' check';
                if (dipilih && dipilih.r === r && dipilih.c === c) el.className += ' sel';
                var p = state.board[r][c];
                if (p) {
                    var span = document.createElement('span');
                    span.className = 'piece ' + p.c;
                    span.textContent = GLIF[p.c][p.t];
                    el.appendChild(span);
                }
                var td = tujuan[r + '_' + c];
                if (td) {
                    var ind = document.createElement('div');
                    ind.className = state.board[r][c] ? 'ring' : 'dot';
                    el.appendChild(ind);
                }
                el.setAttribute('data-r', r);
                el.setAttribute('data-c', c);
                el.addEventListener('click', onKlik);
                boardWrap.appendChild(el);
            }
        }
        var urut = flipped ? FILES.slice().reverse() : FILES;
        coordRow.innerHTML = urut.map(function(f){ return '<span>' + f + '</span>'; }).join('');
    }

    function perbaruiStatus(){
        if (kunci) { statusBar.className = 'statusBar'; statusBar.textContent = 'Komputer sedang berpikir...'; return; }
        var moves = semuaLangkahLegal(state, state.giliran);
        var skak = rajaDiskak(state, state.giliran);
        if (moves.length === 0) {
            state.status = 'selesai';
            if (skak) {
                if (state.giliran === 'w') { statusBar.className = 'statusBar kalah'; statusBar.textContent = 'Skakmat — Komputer menang'; }
                else { statusBar.className = 'statusBar menang'; statusBar.textContent = 'Skakmat — Kamu menang! 🎉'; }
            } else { statusBar.className = 'statusBar'; statusBar.textContent = 'Remis (stalemate)'; }
            return;
        }
        if (skak) { statusBar.className = 'statusBar skak'; statusBar.textContent = (state.giliran === 'w' ? 'Kamu' : 'Komputer') + ' sedang skak!'; }
        else { statusBar.className = 'statusBar'; statusBar.textContent = state.giliran === 'w' ? 'Giliran kamu (Putih)' : 'Giliran komputer...'; }
    }

    function jalankanAI(){
        kunci = true;
        gambar(); perbaruiStatus();
        setTimeout(function(){
            var mv = langkahAI();
            if (mv) state = terapkan(state, mv, 'q');
            kunci = false;
            dipilih = null; legalDariPilihan = [];
            gambar(); perbaruiStatus();
        }, 260);
    }

    function tampilkanPromo(mv){
        promoTunda = mv;
        promoRow.innerHTML = '';
        ['q','r','b','n'].forEach(function(t){
            var btn = document.createElement('button');
            btn.className = 'promoBtn';
            btn.textContent = GLIF.w[t];
            btn.addEventListener('click', function(){
                promoOverlay.style.display = 'none';
                selesaikanLangkah(promoTunda, t);
                promoTunda = null;
            });
            promoRow.appendChild(btn);
        });
        promoOverlay.style.display = 'flex';
    }

    function selesaikanLangkah(mv, promo){
        state = terapkan(state, mv, promo || 'q');
        dipilih = null; legalDariPilihan = [];
        gambar(); perbaruiStatus();
        if (state.status !== 'selesai' && !kunci) jalankanAI();
    }

    function onKlik(e){
        if (kunci || state.status === 'selesai' || promoOverlay.style.display === 'flex') return;
        var r = Number(this.getAttribute('data-r'));
        var c = Number(this.getAttribute('data-c'));
        if (state.giliran !== 'w') return;
        if (dipilih) {
            var cocok = null;
            for (var i = 0; i < legalDariPilihan.length; i++) {
                if (legalDariPilihan[i].ke.r === r && legalDariPilihan[i].ke.c === c) { cocok = legalDariPilihan[i]; break; }
            }
            if (cocok) {
                riwayat.push(kloneState(state));
                if (cocok.promosi) { tampilkanPromo(cocok); return; }
                selesaikanLangkah(cocok, 'q');
                return;
            }
        }
        var p = state.board[r][c];
        if (p && p.c === 'w') {
            dipilih = { r: r, c: c };
            legalDariPilihan = langkahLegalKotak(state, r, c);
        } else {
            dipilih = null; legalDariPilihan = [];
        }
        gambar();
    }

    document.getElementById('resetBtn').addEventListener('click', function(){
        if (kunci) return;
        state = state0(); dipilih = null; legalDariPilihan = []; riwayat = [];
        gambar(); perbaruiStatus();
        captionText.textContent = '${nama} • Level ${kedalaman}';
    });

    document.getElementById('undoBtn').addEventListener('click', function(){
        if (kunci || !riwayat.length) return;
        state = riwayat.pop();
        dipilih = null; legalDariPilihan = [];
        gambar(); perbaruiStatus();
    });

    document.getElementById('flipBtn').addEventListener('click', function(){
        flipped = !flipped;
        gambar();
    });

    gambar();
    perbaruiStatus();
})();
</script>
`;
}

// Handler utama bot (Disamakan strukturnya dengan plugin-plugin lu sebelumnya)
async function handler(m, { sock, conn }) {
    const client = sock || conn;

    if (typeof m.react === 'function') await m.react('♟');

    try {
        const htmlPayload = renderHtmlCatur({ 
            judul: 'Catur Klasik', 
            pemain: 'Kurumi User', 
            level: 2 
        });

        await client.relayMessage(
            m.chat,
            {
                messageContextInfo: {
                    deviceListMetadata: {},
                    deviceListMetadataVersion: 2,
                    botMetadata: {
                        messageDisclaimerText: "",
                        botResponseId: "kurumi-chess-plugin",
                        verificationMetadata: {
                            proofs: [
                                {
                                    version: 1,
                                    useCase: 1,
                                    signature: "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LVZlcmlmaWNhdGlvblNpZ25hdHVyZS5NZXRhZGF0YeN55YRyad2+ZA==",
                                    certificateChain: [
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGEOvtJr968bbpKdZreOTwkk9aPN++XPE60RfuzNLkXXc7LE8BOkJOWRpo2oNXaRJ3uCNJ43HY3A+oetnvHSfcxWqmvvTSrBOI5V1NOD6RMsZ/st1XVPUx83AGps1l5jYBOYzqMNy6un2tToJ2Bt9bXRo29tWLZTu8m7TNY/hISwVpVc5tjSet5U7btPN+dMIx2UvykB1jcbWGsdklheeuz8RXSStNXzeaGvsf1lpZ/ugLE4b2BdmlRNKrY6zLE4qFtRYQoS7axOyQX+4QUyN2m9bfm7urQmn+QRSXJwMO7X5kAJJLbkVGJFt9Pm9VXPwQVrK2aaqiXlpusj+7DfDw00OULmYMmZDTqXM0nUVLxj13z0LhMQoQhhNG8utdUn4uKOFceliTZ/xiP+A54GnX9620641bqw3ctfh9NNXPsTEK8hAUD7FDqUhVntHmoEYYEHq8X1tHHZYP49/f2iezTiE8AUaoZo42/jIWQIKohOGNUib2hEqMkW8NsR8vPihvNuqPc0zKZcl6359YFQdjiiW8kCRD/rsDOr9v1eYLFZKYloFyzFqEgj+jcG/V47elOjShJ5CCPwatXwP6HIloVwtgygFsnOFmCg6Ojoivfoz8Nw1qxFwg5OU2cq/1WbWNELKnaFg4eUWCAIJ/3ZIJsEPkgemZxGhE+hdiNn9dkQYBJs1kx2BxdIkJmQ9vJSKkrMz6lTxZM3IJ9mhmKS6zYdU1ppeAao0/ayte997DQParb/AHLN79g0iW1ad0z8ir5jAl0q3a+UZPTSa4YiSqC2PZ/gfxG5wvL2mKmeKowG0RXjmEp5iNxrni+T/HRLZOoH7y0DQ24nMCPg",
                                        "TklYRUwuTWVzc2FnZUJ1aWxkZXJWNC43LUNlcnRpZmljYXRlQ2hhaW4uTWV0YWRhdGHsL0Ccm0ELINFZ2IaBhKaeWnVuh0o6nZLCioCn9xpSADzwIS5VCWO+1eVXT2atJOyf7FYlpB0/JA3Us+aQtekuIkHu/zBXijORZ4ClF4+sF3cSTNg6gY/+6iwLK/zs3bMg+GeJrcI65vXfs95Shxlb2Rd5GRT2/2yBmR6Zkf5QwMJuptUHWtM26WY7/xlkEKGFYDZVqOSylusiOzSALa815zC6dCiHoJNLBEKMlaZZQOk57/+OYoU5zzTaEgLhyvNFHSyAlyLQ3SGFtVHAaJZHSmmSPyJowCOB+92Gkk6SWVMsk6FbU8QJWFtlhzV/W/gZ7WzUlS/AKgN0th9/cq20ToFkW7X9c+rtYavufmuieqFhXgaMD8AGsoN9QC/HzNC9D1nydPfFYEUr9BHVy2nF5gM58Y59r2rT8p5LPARIkUp8g+5DLhyW0tdZFZ1305o4AHCayZnp5rjcU2Xi/c1Qf/djBGakmijlMs4aMzKJYD0c4Q8jdI7sNyd876K2wRD+L6KeD2QB3PtCS4P7BWAl5gh5CJ6ZBrwcaKXZqcSjEwm52MqVCgYZdapAaNYUy/QndttjLOG0wxxwuX1hIhMjPnIKZR1kwnqD5EqlHpilrnojRZvjVGN4zEKmilS8rNstt4HHs/D849W+Q6LRVWiWMs0cT2IugrX+Skxd8En7Gq52UEmuVBrSTpN+UpIu20NsVb9lsvuYh3XO441606tOEY2eKcZJdTtqrOTNqbbTk0zVn1yhbOCvmfctBNDhTwaC5QMi0P9wjU5XI9SBtkdQLizc5oqpoiHeqgb8+aJHVLcbgIJ/KLZKtRWFDfzRNM02Csx4etUUapVd2NA/L0oMs/O5T9sVj9FBJ7q99GWr3PVmxJb36mHZLXC4k1gGN9swE0LtzYsUdT5tUo9ri/hS3W/SM+F1p4Kh4QIgRcG3ciIHGN44bnDh3HDCz0fDnzKYw0bclMxZPctEyJ5gEOPF6OAkjD9dEaRGq/tEPf1k9Aub+v2dEjnfrYWAm4E5Zfhs2Xh0CT0k+SzhgKd0K/46ChJ20G5+blwpIvahvTVS68+aVIX6CwXs4tcVx6FnmVsMOOkIasfaqQLZYbNBkuLoZnQAq4j8yRekrQ=="
                                    ]
                                }
                            ]
                        }
                    }
                },
                botForwardedMessage: {
                    message: {
                        richResponseMessage: {
                            messageType: 1,
                            submessages: [{ messageType: 2, messageText: `Game Catur VS Komputer Dimulai!` }],
                            unifiedResponse: {
                                data: Buffer.from(JSON.stringify({
                                    "response_id": "kurumi-chess-plugin",
                                    "sections": [{ 
                                        "view_model": { 
                                            "primitive": { 
                                                "__typename": "GenAIaeacdsnwHtmlPrimitive", 
                                                "payload": htmlPayload, 
                                                "trusted_sources": ["hirara.dev"] 
                                            }, 
                                            "__typename": "GenAISingleLayoutViewModel" 
                                        } 
                                    }]
                                })).toString('base64')
                            },
                            contextInfo: {
                                forwardingScore: 1,
                                isForwarded: true,
                                forwardedAiBotMessageInfo: {
                                    botJid: "867051314767696@bot"
                                },
                                forwardOrigin: 4
                            }
                        }
                    }
                }
            },
            {}
        );

    } catch (error) {
        console.error('Chess Plugin Error:', error);
        if (typeof m.react === 'function') await m.react('❌');
        await m.reply('❌ *GAGAL*\n\n> ' + error.message);
    }
}

export { pluginConfig as config, handler };