const pluginConfig = {
    name: 'menu2',
    alias: ['mainmenu2'],
    category: 'main',
    description: 'Menampilkan menu utama bot dengan tombol interaktif (Versi 2)',
    usage: '.menu2',
    example: '.menu2',
    isOwner: false,
    isPremium: false,
    isGroup: false,
    isPrivate: false,
    cooldown: 5,
    energi: 0,
    isEnabled: true
}

async function handler(m, { sock }) {
    m.react('⏳')

    try {
        const menuText = 
            `Halo bos! 👋\n\n` +
            `Selamat datang di Main Menu Bot. Silakan pilih salah satu tombol di bawah ini untuk melihat daftar menu atau menghubungi Owner.\n\n` +
            `> _Gunakan bot dengan bijak!_`

        const interactiveMessage = {
            viewOnceMessage: {
                message: {
                    interactiveMessage: {
                        header: {
                            title: "🤖 *SISTEM BOT AKTIF* 🤖",
                            hasMediaAttachment: false 
                        },
                        body: {
                            text: menuText
                        },
                        footer: {
                            text: "⚡ Powered by ESM Bot"
                        },
                        nativeFlowMessage: {
                            buttons: [
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "📋 Pilihan Menu",
                                        id: ".allmenu" 
                                    })
                                },
                                {
                                    name: "quick_reply",
                                    buttonParamsJson: JSON.stringify({
                                        display_text: "👑 Owner",
                                        id: ".owner" 
                                    })
                                }
                            ],
                            messageParamsJson: ""
                        }
                    }
                }
            }
        }

        await sock.relayMessage(m.chat, interactiveMessage.viewOnceMessage.message, {
            messageId: m.key.id
        })

        m.react('☑️')

    } catch (error) {
        console.error('[Menu2 Plugin Error]', error)
        m.react('⚙️')
        m.reply(`❌ *Gagal memuat menu:*\n> _${error.message}_`)
    }
}

export { pluginConfig as config, handler }